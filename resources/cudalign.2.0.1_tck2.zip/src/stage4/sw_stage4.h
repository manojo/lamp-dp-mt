void stage4(Job* job);
