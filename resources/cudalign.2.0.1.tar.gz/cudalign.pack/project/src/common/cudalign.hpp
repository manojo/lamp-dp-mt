#pragma once

#include "cuda_configs.hpp"
#include "sw_configs.hpp"
#include "Sequence.hpp"
#include "Job.hpp"
#include "SpecialRowReader.hpp"
#include "SpecialRowWriter.hpp"
#include "MidpointsFile.hpp"
#include "Alignment.hpp"
#include "Timer.hpp"
#include "macros.hpp"
#include "cuda_util.hpp"

// This is for IDE's code assistance only. 
// Set -D__DISABLE_IDE_COMPILATION_ASSISTANCE__ for proper compilation
#ifndef __DISABLE_IDE_CODE_ASSISTANCE__
#include "cuda_ide_code_assistance.hpp"
#endif
