// **********************
// This is for IDE's code assistance only. Set -D__DISABLE_IDE_COMPILATION_ASSISTANCE__ for proper compilation
// **********************
#pragma once

#include <cuda_runtime.h>
#include <common_functions.h>
#include <cuda_surface_types.h>
#include <cuda_texture_types.h>
#include <device_functions.h>
#include <device_launch_parameters.h>
#include <texture_fetch_functions.h>
#include <cuda_texture_types.h>
#include <host_defines.h>
#include <texture_types.h>
#include <vector_functions.h>
#include <vector_types.h>

template<class T, int dim = 1, enum cudaTextureReadMode mode = cudaReadModeElementType> struct texture;

struct int2{int x, y;};
static unsigned int tex1Dfetch(texture<unsigned int, 1, cudaReadModeElementType> t, int x);
static unsigned char tex1Dfetch(texture<unsigned char, 1, cudaReadModeElementType> t, int x);
static int tex1Dfetch(texture<int, 1, cudaReadModeElementType> t, int x);
static char tex1Dfetch(texture<char, 1, cudaReadModeElementType> t, int x);


extern "C"
{
	uint3 const threadIdx = {0,0,0};
	uint3 const blockIdx = {0,0,0};
	dim3 const blockDim = dim3();
	dim3 const gridDim = dim3();
	int const warpSize = 0;
}
#endif
