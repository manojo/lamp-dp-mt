#pragma once

#include "../common/cudalign.hpp"

void stage2(Job* job);
