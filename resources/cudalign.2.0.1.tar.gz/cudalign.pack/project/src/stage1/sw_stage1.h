#pragma once

void stage1(Job* job);