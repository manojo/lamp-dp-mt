nvcc --ptx -I/opt/NVIDIA_GPU_Computing_SDK/C/common/inc/ -I/usr/local/cuda/include/ -D__DISABLE_IDE_CODE_ASSISTANCE__ --ptxas-options=-v phase1/sw_phase1.cu
