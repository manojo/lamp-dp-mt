#pragma once

#include "../common/cudalign.hpp"

void stage3(Job* job);
