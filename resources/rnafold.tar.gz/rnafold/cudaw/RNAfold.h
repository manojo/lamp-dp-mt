#ifndef RNAfold_h
#define RNAfold_h

int main_rnafold_mfe(toptions *_opts, tsequence *_seq);


#endif

