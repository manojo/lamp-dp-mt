#!/bin/ksh

set -u

NO_CONFIG_MF="foo"
export NO_CONFIG_MF

GAPC=../../gapc
GHC=ghc
MAKE=make
MAKEFLAGS=-I../..

TEMP=./temp
GRAMMAR=../../grammar
LHS_DIR=..
RTLIB=../../rtlib
CPPFLAGS_EXTRA="-I../.. -I../../librna"
LDLIBS_EXTRA=""
RUN_CPP_FLAGS=""

if [ -e ../config.mf ]; then
  CONFIG_MF=config.mf
else
  CONFIG_MF=config/generic.mf
fi

err_count=0
succ_count=0
failed=0

FILTER=.

if [ $# == 1 ]; then
  FILTER=$1
fi


mkdir -p $TEMP
cd $TEMP

echo include $CONFIG_MF > gapc_local.mf

. ../tool.sh

RAND="../../../randseq/RandSeqMain -l"

check_rand_eq()
{
  REPEATS=$6
  LENGTH=$7
  cpp_base=${1%%.*}
  lhs_base=${2%%.*}
  build_cpp $GRAMMAR/$1 $cpp_base $3
  build_haskell $2 $lhs_base
  for i in `seq $LENGTH`; do
    for j in `seq $REPEATS`; do
  echo +------------------------------------------------------------------------------+
  failed=0
  temp=$failed
    input=`$RAND $i`
    echo Length $i, Repeat $j, Input: $input
    run_cpp $cpp_base $3 $input $5
    run_haskell $lhs_base $3 $input $5
    cmp_output $cpp_base $lhs_base $3 $5
    if [ $temp != $failed ]; then
      echo --++--FAIL--++--
      err_count=$((err_count+1))
      exit 1
    else
      echo OK
      succ_count=$((succ_count+1))
    fi
  echo +------------------------------------------------------------------------------+
    done
  done
}


#check_rand_eq adpf.gap AdpfMain.lhs bpmaxpp unused foo 10 50

GAPC="../../gapc -t" # --cyk"
CPPFLAGS_EXTRA="-I../.. -I../../librna -I.."
LDLIBS_EXTRA=../../librna/rnalib.o
CPP_FILTER="sed -i -e s/(\([^,]\\+\),[^)]\\+)/\\1/ a"

#check_rand_eq rnashapesmfe.gap RNAshapesMfeMain.lhs mfepp unused foo 10 50

CPPFLAGS_EXTRA="-I../.. -I../../librna -I.. -O3 -DNDEBUG"
OWN_CMP_OUTPUT="cmp_fp_output"
EPSILON=1000
check_rand_eq rnashapespf.gap RNAshapesPFMain.lhs pf unused foo 5 100

echo
. ../stats.sh


