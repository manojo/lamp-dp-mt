/* {{{

    This file is part of gapc (GAPC - Grammars, Algebras, Products - Compiler;
      a system to compile algebraic dynamic programming programs)

    Copyright (C) 2008-2011  Georg Sauthoff
         email: gsauthof@techfak.uni-bielefeld.de or gsauthof@sdf.lonestar.org

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

}}} */


#include "ast.hh"
#include "log.hh"
#include "terminal.hh"

#include "signature.hh"

#include "instance.hh"
#include "product.hh"
#include "list_warn.hh"

#include "expr.hh"
#include "const.hh"

#include "arg.hh"

#include "statement.hh"

#include "opt_choice_visitor.hh"

#include "fn_def.hh"

#include "backtrack.hh"
#include "subopt.hh"

#include <cassert>
#include <sstream>

AST::AST()
  :
    product_(0),
    grammars_(0),
    selected_grammar(0),
    signature(NULL),
  first_instance(NULL), instance_(0),
  backtrack_product(0),
  backtrack_filter(0),
  original_product(0),
  char_type(0)
{
  Type::add_predefined(types);
}

Type::Base *AST::get_type(const std::string &name, const Loc &l)
{
  hashtable<std::string, Type::Base*>::iterator i = types.find(name);
  if (i != types.end()) {
    return i->second;
  }
  Log::instance()->error(l, "Usage of unknown type " + name + ".");
  return NULL;
}

Type::Base *AST::get_type(const std::string &name)
{
  hashtable<std::string, Type::Base*>::iterator i = types.find(name);
  if (i != types.end()) {
    return i->second;
  }
  Log::instance()->error("Usage of unknown type " + name + ".");
  return NULL;
}

void AST::add_type(std::string *name, const Loc &l, Type::Base *base)
{
  hashtable<std::string, Type::Base*>::iterator i = types.find(*name);
  if (i == types.end()) {
    types[*name] = base;
    type_def_list.push_back(base);
    return;
  }
  Log::instance()->error(l, "Type " + *name + " already defined");
  Log::instance()->error(i->second->location, "here.");
}

void AST::add_sig_types(hashtable<std::string, Arg*> & args, Signature *s)
{
  for (hashtable<std::string, Arg*>::iterator i = args.begin(); i != args.end();
      ++i) {
    Arg *arg = i->second;
    if (*arg->name == "alphabet")
      continue;
    Type::Signature *t = new Type::Signature(arg->name, arg->location, s);
    add_type(arg->name, arg->location, t);
  }
}


bool AST::check_signature()
{
  bool r = true;
  bool b = signature->check();
  r = r && b;
  b = grammar()->check_signature(*signature);
  r = r && b;
  return r;
}

bool AST::check_algebras()
{
  bool r = true;
  for(hashtable<std::string, Algebra*>::iterator i = algebras.begin();
      i != algebras.end(); ++i) {
    bool b = i->second->check_signature(*signature);
    r = r && b;
  }
  return r;
}


bool AST::check_instances(Instance *instance)
{
 for (hashtable<std::string, Algebra*>::iterator i = algebras.begin();
      i != algebras.end(); ++i)
   i->second->annotate_terminal_arguments(*signature);

 instance->check_alphabets();

  bool r = true;
  for (hashtable<std::string, Instance*>::iterator i = instances.begin();
       i != instances.end(); ++i) {
    bool b = i->second->init(instance);
    r = r && b;
  }
  return r;
}

void AST::print_instances(std::ostream &s)
{
  for (hashtable<std::string, Instance*>::iterator i = instances.begin();
       i != instances.end(); ++i)
    s << *i->second << std::endl;
}

Instance *AST::instance(const std::string &n)
{
  if (n.empty())
    if (first_instance)
      return first_instance;
    else {
      Log::instance()->error("No instance defined in input file.");
      return NULL;
    }
  hashtable<std::string, Instance*>::iterator i = instances.find(n);
  if (i == instances.end()) {
    Log::instance()->error("Could not find instance " + n + ".");
    return NULL;
  }
  Instance *instance = i->second;
  return instance;
}

bool AST::insert_instance(std::string &n)
{
  Instance *inst = instance(n);
  if (!inst)
    return false;
  bool b = insert_instance(inst);
  return b;
}

bool AST::insert_instance(Instance *inst)
{
  assert(inst);
  instance_ = inst;
  grammar()->reset_types();

  update_alphabet_types(inst->product->algebra()->params["alphabet"]);

  bool b = grammar()->check_signature(*inst->product->algebra());
  if (b)
    warn_unused_fns(*inst);

  return b;
}

bool AST::instance_grammar_eliminate_lists(std::string &n)
{
  Instance *inst = instance(n);
  if (!inst)
    return false;
  bool b = instance_grammar_eliminate_lists(inst);
  return b;
}

bool AST::instance_grammar_eliminate_lists(Instance *inst)
{
  assert(inst);
  inst->eliminate_lists();
  grammar()->eliminate_lists();
  return true;
}

// callable after insert_instance(), instance_grammar_eliminate_lists()
//   and Grammar::init_list_sizes() are called
void AST::warn_missing_choice_fns(Instance *instance)
{
  List_Warn lw(instance);
  grammar()->traverse(lw);
}

void AST::warn_missing_choice_fns()
{
  List_Warn lw;
  grammar()->traverse(lw);
}

void AST::warn_user_table_conf_suboptimal()
{
  Runtime::Asm::Poly rt;
  rt  = grammar()->runtime();
  Runtime::Asm::Poly opt;
  opt  = grammar()->asm_opt_runtime();
  if (rt != opt) {
    std::ostringstream o;
    if (grammar()->tabulated.empty()) {
      o << "No automatic table design is selected and no table configuration\n"
        "is supplied: Yields an asymptotically suboptimal runtime of " << rt ;
    } else {
      o << "Specified table configuration "
        " yields an asymptotically suboptimal runtime:\n"
        << '\t' << "Runtime under user supplied table configuration is " << rt;
    }
    o << "\n\t  (optimal rt is " << opt << ").\n"
      << "\nTry adding option -t for automatic table design.";
    Log::instance()->warning(grammar()->location, o.str());
  }
}

void AST::codegen()
{
  sf_filter_code.clear();
  grammar()->codegen(*this);
}

void AST::print_code(Printer::Base &out)
{
  grammar()->print_code(out);
}


void AST::derive_roles()
{
  for(hashtable<std::string, Algebra*>::iterator i = algebras.begin();
      i != algebras.end(); ++i) {
    i->second->derive_role();
  }
}

struct Push_Type_Cmp {
  bool operator() (const std::pair<Type::List::Push_Type,
                                   std::string> &a,
                   const std::pair<Type::List::Push_Type,
                                   std::string>  &b) 
  { 
    //return *p1 < *p2;
    Type::List::Push_Type x = a.first;
    Type::List::Push_Type y = b.first;
    if (x == Type::List::NORMAL && y != Type::List::NORMAL)
      return false;
    if (x != Type::List::NORMAL && y == Type::List::NORMAL)
      return true;
    if (x == Type::List::NORMAL && y == Type::List::NORMAL)
      return true;
    return true;
  }
};

struct FixLink : public Visitor {
  void visit(Alt::Link &a)
  {
    a.optimize_choice();
  }
};


void AST::optimize_choice(Instance &inst)
{
  if (!inst.product->contains_only_times())
    return;

  unsigned int width = inst.product->width();
  unsigned int n = 0;
  Algebra *l = inst.product->nth_algebra(n);

  std::vector<std::pair<Type::List::Push_Type, std::string> > v;

  for (hashtable<std::string, Fn_Def*>::iterator i = l->choice_fns.begin();
      i != l->choice_fns.end(); ++i) {
    Fn_Def *fn = i->second;
    Expr::Fn_Call::Builtin choice_type = fn->choice_fn_type();
    Type::List::Push_Type push = Type::List::NORMAL;
    if (fn->choice_mode() != Mode::KSCORING) {
      if (width == 1) {
        switch (choice_type) {
          case Expr::Fn_Call::SUM : push = Type::List::SUM; break;
          case Expr::Fn_Call::MINIMUM : push = Type::List::MIN; break;
          case Expr::Fn_Call::MAXIMUM : push = Type::List::MAX; break;
          default: ;
        }
        // FIXME add this choice fn optimization to max_other etc.
        // -> generic comparison predicates are needed for this
        if (push != Type::List::NORMAL) {
          fn->add_simple_choice_fn_adaptor();
        }
      } else {
        switch (choice_type) {
          case Expr::Fn_Call::MINIMUM : push = Type::List::MIN_OTHER; break;
          case Expr::Fn_Call::MAXIMUM : push = Type::List::MAX_OTHER; break;
          default: ;
        }
        if (push != Type::List::NORMAL &&
            width == 2 &&
            inst.product->right()->algebra()->choice_fn(fn)->choice_mode()
              == Mode::PRETTY) {
          Fn_Def *f = inst.product->algebra()->choice_fn(fn);
          f->stmts.clear();
          f->add_simple_choice_fn_adaptor();
        }
      }
    }
    v.push_back(std::make_pair(push, i->first));
  }
  std::sort(v.begin(), v.end(), Push_Type_Cmp());
  for (std::vector<std::pair<Type::List::Push_Type, std::string> >::iterator
       i = v.begin(); i != v.end(); ++i) {
    hashtable<std::string, Fn_Def*>::iterator j
      = inst.product->algebra()->choice_fns.find(i->second);
    assert(j != inst.product->algebra()->choice_fns.end());

    Opt_Choice_Visitor v(j->second, i->first);
    grammar()->traverse(v);
  }
  FixLink fl;
  grammar()->traverse(fl);
}

#include "classify_visitor.hh"

void AST::optimize_classify(Instance &inst)
{
  assert(inst.product);
  if (!inst.product->left_is_classify() || !inst.product->one_per_class()) {
    if (kbest)
      throw LogError("You specified --kbest but the product is not classifying");
    return;
  }

  for (hashtable<std::string, Fn_Def*>::iterator i =
       inst.product->algebra()->choice_fns.begin();
       i != inst.product->algebra()->choice_fns.end(); ++i) {
    Statement::Hash_Decl *hdecl = inst.generate_hash_decl(*i->second, kbest);
    hash_decls_.push_back(hdecl);

    Type::List::Push_Type t = Type::List::HASH;
    Opt_Choice_Visitor v(i->second, t, hdecl);
    grammar()->traverse(v);

    Classify_Visitor w;
    grammar()->traverse(w);

    if (inst.product->is(Product::SINGLE))
      i->second->disable();
    else
      i->second->optimize_classify();

  }

  FixLink fl;
  grammar()->traverse(fl);

  Product::iterator i = Product::begin(inst.product);
  assert(i != Product::end());
  ++i;
  for (; i != Product::end();
       ++i) {
    for (hashtable<std::string, Fn_Def*>::iterator j =
         (*i)->algebra()->choice_fns.begin();
         j != (*i)->algebra()->choice_fns.end(); ++j)
      j->second->disable();
  }
}
void AST::backtrack_gen(Backtrack_Base &bt)
{
  assert(instance_);
  Algebra *score = instance_->product->bt_score_algebra();

  bt.gen_backtraces(backtrack_product, *score);
  bt.gen_nt_decls(grammar()->nts());

  Type::Base *t = get_type("alphabet");
  Type::Alphabet *alph = dynamic_cast<Type::Alphabet*>(t);
  assert(alph);
  assert(!alph->simple()->is(Type::ALPHABET));
  bt.gen_algebra(*signature, alph->temp ? alph->temp : new Type::Char());

  bt.gen_instance(score);
  //bt.gen_nt_decls(grammar()->nts());
  bt.apply_filter(backtrack_filter);
  if (original_product &&
       (original_product->is(Product::TAKEONE) || original_product->no_coopt()) )
    cg_mode.set_cooptimal(false);
  bt.gen_backtrack(*this);
  bt.gen_instance_code(*this);

}

Instance *AST::split_instance_for_backtrack(std::string &n)
{
  Instance *i = instance(n);
  if (!i)
    return 0;
  check_instances(i);
  Product::Two *two = dynamic_cast<Product::Two*>(i->product);
  if (!two)
    throw LogError("You have to use a product instance with --backtrack.");
  /* well, !PRETTY is legitimate, too ...
  Algebra *pp = two->right()->algebra();
  if (!pp->is_compatible(Mode::PRETTY))
    throw LogError("--backtrack is not possible, because RHS of product is not"
        " of type pretty");
        */

  original_product = two;

  backtrack_product = two->right();
  backtrack_filter = two->filter();
  Instance *score = new Instance(i->name(), two->left(), grammar());
  return score;
}

std::pair<Instance*, Instance*> AST::split_classified(const std::string &n)
{
  Instance *i = instance(n);
  if (!i)
    throw LogError("Instance does not exist.");
  check_instances(i);
  if (!i->product->left_is_classify())
    throw LogError("Left algebra is not classifying.");
  Instance *score = 0;
  for (Product::iterator j = Product::begin(i->product); j != Product::end();
       ++j) {
    if (!(*j)->is(Product::SINGLE))
      continue;
    bool scoring = (*j)->algebra()->is_compatible(Mode::SCORING);
    if (scoring) {
      score = new Instance(i->name(), *j, grammar());
      break;
    }
  }
  for (Product::iterator j = Product::begin(i->product); j != Product::end();
       ++j) {
    if (!(*j)->is(Product::SINGLE))
      continue;
    bool pretty = (*j)->algebra()->is_compatible(Mode::PRETTY);
    if (pretty) {
      backtrack_product = *j;
      break;
    }
  }
  return std::make_pair(score, i);
}

#include "unused_visitor.hh"

void AST::warn_unused_fns(Instance &inst)
{
  Unused_Visitor v;
  grammar()->traverse(v);
  hashtable<std::string, Fn_Def*> &fns = inst.product->algebra()->fns;
  for (hashtable<std::string, Fn_Def*>::iterator i = fns.begin();
       i != fns.end(); ++i) {
    Fn_Def *f = i->second;
    if (!f->in_use()) {
      Fn_Decl *x = signature->decl(*f->name);
      if (x) {
        Log::instance()->warning(x->location, "Signature symbol " + *f->name
            + " unused in grammar " + *grammar()->name + ".");
      }
    }
    inst.product->set_in_use(*f);
  }
}

#include "options.hh"

void AST::check_backtrack(const Options &opts)
{
  if (opts.backtrack) {
    Algebra *a = instance_->product->algebra();
    for (hashtable<std::string, Fn_Def*>::iterator i = a->choice_fns.begin();
         i != a->choice_fns.end(); ++i) {
      if (i->second->choice_mode() == Mode::MANY)
        throw LogError(i->second->location, "k-scoring choice function "
            + *i->second->name + " from instance " + *instance_->name()
            + " is not allowed with --backtrace. Try --kbacktrace instead.");
    }
  }
  if (instance_->product->contains(Product::OVERLAY) && !opts.backtrack)
    throw LogError(instance_->loc(), "The overlay product needs a --backtrace or --sample switch.");
  cg_mode.set_sample(opts.sample);
}

#include "char_visitor.hh"

void AST::set_tracks()
{
  size_t tracks = grammar()->axiom->tracks();
  input.set_tracks(tracks);

  size_t i = seq_decls.size();
  assert(i <= tracks);
  seq_decls.resize(tracks);
  for (; i < tracks; ++i) {
    std::ostringstream o;
    o << "t_" << i << "_seq";
    seq_decls[i] =
      new Statement::Var_Decl(new Type::Seq(), new std::string(o.str()));
  }
}

void AST::derive_temp_alphabet()
{
  set_tracks();

  Char_Visitor v;
  grammar()->traverse(v);
  const std::list<Type::Base*> &list = v.list();
  Type::Base *res = 0;
  switch (list.size()) {
    case 0 : res = new Type::Char();
             break;
    case 1 : res = list.front();
             char_type = res;
             break;
    default: throw LogError("Found multiple CHAR() terminal parsers with different"
                 " argument types in the grammar."
                 " This implies an ill defined alphabet.");
             break;
  }
  update_alphabet_types(res);
}

void AST::update_alphabet_types(Type::Base *res)
{
  hashtable<std::string, Type::Base*>::iterator i =
    types.find("alphabet");
  assert(i != types.end());
  dynamic_cast<Type::Alphabet*>(i->second)->temp = res;

  hashtable<std::string, Symbol::Base*>::iterator j = grammar()->NTs.find("CHAR");
  if (j != grammar()->NTs.end()) {
    Symbol::Terminal *t = dynamic_cast<Symbol::Terminal*>(j->second);
    assert(t);
    t->force_type(res);
  }
  j = grammar()->NTs.find("CHAR_SEP");
  if (j != grammar()->NTs.end()) {
    Symbol::Terminal *t = dynamic_cast<Symbol::Terminal*>(j->second);
    assert(t);
    t->force_type(res);
  }
  j = grammar()->NTs.find("NON");
  if (j != grammar()->NTs.end()) {
    Symbol::Terminal *t = dynamic_cast<Symbol::Terminal*>(j->second);
    assert(t);
    t->force_type(res);
  }
  hashtable<std::string, Fn_Decl*>::iterator k = Fn_Decl::builtins.find("CHAR");
  assert(k != Fn_Decl::builtins.end());
  k->second->return_type = res;
  k->second->types.clear();
  k->second->types.push_back(res);
}

void AST::update_seq_type(Instance &inst)
{
  Algebra *a = inst.product->algebra();
  assert(a);
  hashtable<std::string, Type::Base*>::iterator i = a->params.find("alphabet");
  assert(i != a->params.end());
  Type::Base *type = i->second;
  if (char_type && !type->is_eq(*char_type)) {
    std::ostringstream o;
    o << "Algebra alphabet type (" << *type << ") does not match the detected"
      << " CHAR() terminal parser type (" << *char_type << ").";
    throw LogError(inst.loc(), o.str());
  }
  for (std::vector<Statement::Var_Decl*>::iterator x = seq_decls.begin();
      x != seq_decls.end(); ++x) {
    Type::Seq *seq = dynamic_cast<Type::Seq*>((*x)->type);
    assert(seq);
    seq->element_type = type;
  }
}


void AST::set_window_mode(bool w)
{
  if (!w)
    return;
  if (grammar()->axiom->tracks() > 1)
    throw LogError("Window mode currently just works with one-track grammars.");

  window_mode = w; 

  grammar()->window_table_dims();
}

bool AST::grammar_defined(const std::string &n) const
{
  assert(grammars_);
  for (std::list<Grammar*>::iterator i = grammars_->begin();
       i != grammars_->end(); ++i)
    if (*(*i)->name == n)
      return true;
  return false;
}

Grammar *AST::grammar(const std::string&n)
{
  for (std::list<Grammar*>::iterator i = grammars_->begin();
       i != grammars_->end(); ++i)
    if (*(*i)->name == n)
      return *i;
  assert(0);
  return 0;
}

#include <map>

void AST::set_grammars(std::list<Grammar*> *g)
{
  grammars_ = g;
  if (!grammars_->empty())
    selected_grammar = grammars_->back();

  std::map<std::string, Grammar*> h;
  for (std::list<Grammar*>::iterator i = grammars_->begin();
       i != grammars_->end(); ++i) {
    std::map<std::string, Grammar*>::iterator a = h.find(*(*i)->name);
    if (a != h.end()) {
      Log::instance()->error((*i)->location, "Grammar name is used");
      Log::instance()->error(a->second->location, "before.");
      return;
    } else
      h[*(*i)->name] = *i;
  }
}

void AST::select_grammar(const std::string &instname)
{
  Instance *i = instance(instname);
  if (!i)
    return;
  selected_grammar = i->grammar();
}

#include "statement/hash_decl.hh"

void AST::set_class_name(const std::string &n)
{
  for (std::list<Statement::Hash_Decl*>::iterator i = hash_decls_.begin();
       i != hash_decls_.end(); ++i)
    (*i)->set_class_name(n);
}

