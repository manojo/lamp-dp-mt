#include "pfsampleshrep.hh"


#include <cstring>
#include <map>
#include <list>

#include <cstdlib>
#include <unistd.h>
#include <sstream>
#include "generic_opts.hh"


static void output(gapc::class_name &obj, size_t a, size_t b,
    unsigned int repeats)
{

  // FIXME a, b subwords

  typedef std::pair<std::pair<Shape, mfeanswer> , String> Tuple;

  std::map<Shape, std::pair<std::pair<mfeanswer, String>, unsigned int> > set;
  unsigned int sum = 0;

  //gapc::return_type res = obj.run(0, n);

  for (unsigned int rep = 0; rep < repeats; ++rep) {

  intrusive_ptr<Backtrace<Tuple, unsigned int> >  bt = obj.backtrack();
  intrusive_ptr<Backtrace_List<Tuple, unsigned int> > l =
    boost::dynamic_pointer_cast<Backtrace_List<Tuple, unsigned int> >(bt);
  assert(l);
  for (Backtrace_List<Tuple, unsigned int>::iterator i = l->begin();
      i != l->end(); ++i) {
    intrusive_ptr<Backtrace<Tuple, unsigned int> > t = *i;
    assert(t);

    intrusive_ptr<Eval_List<Tuple> > eval = t->eval();
    for (Eval_List<Tuple>::iterator i = eval->begin();
      i != eval->end(); ++i) {
      sum++;

      //std::cout << *i << '\n';

      std::map<Shape, std::pair<std::pair<mfeanswer, String>, unsigned int> >::iterator j = set.find((*i).first.first);
      if (j == set.end()) {
        set[(*i).first.first] = std::make_pair(std::make_pair( (*i).first.second, (*i).second), 1);
      } else {
        if ((*i).first.second < j->second.first.first ) {
          j->second.first.first = (*i).first.second;
          j->second.first.second = (*i).second;
        }
        j->second.second++;
      }
    }
  }

  }

  for (std::map<Shape, std::pair<std::pair<mfeanswer, String>, unsigned int> >::iterator i = set.begin(); i != set.end(); ++i) {
    std::cout << i->first << ' ' << double(i->second.second)/double(sum)
      << ' ' << i->second.first.first.energy << ' ' << i->second.first.second << '\n';
  }
}

int main(int argc, char **argv)
{
#if defined(__SUNPRO_CC) && __SUNPRO_CC <= 0x5100
#warning Enable sync_with_stdio because Sun CC 12 Compiler Bug
#else
  std::ios_base::sync_with_stdio(false);
#endif
  std::cin.tie(0);

  bool all_subwords = false;
  unsigned int repeats = 1000;
  char *inp = 0;
  size_t n = 0;

  int o = 0;
  while ((o = getopt(argc, argv, ":r:s")) != -1) {
    switch (o) {
      case 'r' : repeats = std::atoi(optarg);
                 break;
      case 's' : all_subwords = true;
                 break;
      case '?' :
      case ':' :
                 {
                   std::ostringstream os;
                   os << "Missing argument of " << char(optopt);
                   throw gapc::OptException(os.str());
                 }
      default:
                 {
                   std::ostringstream os;
                   os << "Unknown Option: " << char(o);
                   throw gapc::OptException(os.str());
                 }
    }
  }
  if (!inp) {
    if (optind != argc-1)
      if (optind<argc-1)
        throw gapc::OptException("Spurious arguments/options.");
      else
        throw gapc::OptException("Missing input sequence or no -f.");
    inp = argv[argc-1];
    n = strlen(inp);
    inp = new char[n+1];
    strcpy(inp, argv[argc-1]);
  }

  gapc::class_name obj;
  gapc::Opts opts;
  opts.inputs.push_back(std::make_pair(inp, n));
  obj.init(opts);


  obj.cyk();
  if (all_subwords) {
    // FIXME 
    assert(0);
    for (size_t a = 0; a < n; ++a)
      for (size_t b = a + 6; b <= n; ++b) {
        std::cout << "Subword " << a << ' ' << b << '\n';
        output(obj, a, b, repeats);
      }
  } else {
   output(obj, 0, n, repeats);
  }

  return 0;
}
