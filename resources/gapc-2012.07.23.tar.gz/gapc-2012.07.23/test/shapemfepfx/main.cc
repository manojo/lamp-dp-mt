#include "shapemfepfx.hh"

//typedef Hash::Ref<std::pair<Shape, std::pair<mfeanswer, pfanswer> > , insp_hash_h > hash_h;

#include <cstring>
#include <map>
#include <list>

#include <cstdlib>
#include <unistd.h>
#include <sstream>
#include "generic_opts.hh"

struct Options {
  bool no_co_opt;
  bool no_prob_thresh;
  double prob_thresh;
  double filter_thresh;
  bool disable_nofoldclass;

  bool window_mode;
  size_t window_size;
  size_t window_inc;

  bool no_backtrack;

  Options()
    : no_co_opt(false),
      no_prob_thresh(true),
      prob_thresh(0),
      filter_thresh(0.000001),
      disable_nofoldclass(false),
      window_mode(false),
      window_size(0),
      window_inc(1),
      no_backtrack(false)
  {
  }
};

typedef std::pair<Shape, std::pair<mfeanswer, pfanswer> > Type;

static void output(gapc::class_name &obj, size_t a, size_t b,
    const Options &opt)
{
  std::map<Shape, double> set;

  typedef hash_h axiom_t;
  // typedef List_Ref<std::pair<shape_t, std::pair<mfeanswer, pfanswer> > > axiom_t;

  obj.t_0_left_most = a;
  obj.t_0_right_most = b;
  axiom_t res = obj.run();

  //std::cout << res << '\n';
  double sum = 0;
  for (axiom_t::iterator i = res->begin(); i != res->end(); ++i) {
    set[(*i).first] = (*i).second.second.pf.q1;
    sum += (*i).second.second.pf.q1;
  }

  if (res->is_empty())
    return;

  if (opt.no_backtrack) {
    std::cout << sum << '\n';
    return;
  }

  typedef String pstring;
  // typedef Rope pstring;

  intrusive_ptr<Backtrace<pstring, unsigned int> >  bt =
    obj.backtrack(a, b);
  intrusive_ptr<Backtrace_List<pstring, unsigned int> > l =
    boost::dynamic_pointer_cast<Backtrace_List<pstring, unsigned int> >(bt);
  assert(l);
  for (Backtrace_List<pstring, unsigned int>::iterator i = l->begin();
      i != l->end(); ++i) {
    intrusive_ptr<Backtrace<pstring, unsigned int> > t = *i;
    assert(t);

    intrusive_ptr<Backtrace_Score<Type, pstring, unsigned int> > u =
      boost::dynamic_pointer_cast<Backtrace_Score<Type, pstring, unsigned int> >(t);
    assert(u);


    const Type &score = u->score();

    double prob = set[score.first]/sum;

    if (!opt.no_prob_thresh && prob < opt.prob_thresh)
      continue;
    if (opt.disable_nofoldclass && score.first == '_')
        continue;

    intrusive_ptr<Eval_List<pstring> > eval = u->eval();
    for (Eval_List<pstring>::iterator i = eval->begin();
      i != eval->end(); ++i) {

      std::cout << a << ';' << a + opt.window_size << ';'
        << a << ';' << b << ';'
        << score.first << ';' << prob
        << ';' << score.second.first.energy << ';'
        << *i << '\n';

      if (opt.no_co_opt)
        break;
    }


  }
}

int main(int argc, char **argv)
{
#if defined(__SUNPRO_CC) && __SUNPRO_CC <= 0x5100
#warning Enable sync_with_stdio because Sun CC 12 Compiler Bug
#else
  std::ios_base::sync_with_stdio(false);
#endif
  std::cin.tie(0);

  bool all_subwords = false;
  char *inp = 0;
  size_t n = 0;

  Options opt;
  int o = 0;
  while ((o = getopt(argc, argv, ":r:snp:t:dw:i:f:z")) != -1) {
    switch (o) {
      case 's' : all_subwords = true;
                 break;
                 /* is not enough; use gapc --no-coopt instead
      case 'n' : opt.no_co_opt = true;
                 break;
                 */
      case 'p' : opt.prob_thresh = atof(optarg);
                 opt.no_prob_thresh = false;
                 break;
      case 't' : opt.filter_thresh = atof(optarg);
                 p_func_filter_all<Type>::cutoff_prob = opt.filter_thresh;
                 break;
      case 'd' : opt.disable_nofoldclass = true;
                 break;
      case 'w' : opt.window_mode = true;
                 opt.window_size = atoi(optarg);
                 break;
                 /*
      case 'i' : opt.window_inc = atoi(optarg);
                 break;
                 */
      case 'z' : opt.no_backtrack = true;
                 break;
      case 'f' :
                 {
                   std::ifstream file(optarg);
                   file.exceptions(std::ios_base::badbit |
                       std::ios_base::failbit |
                       std::ios_base::eofbit);
                   std::filebuf *buffer = file.rdbuf();
                   size_t size = buffer->pubseekoff(0, std::ios::end, std::ios::in);
                   buffer->pubseekpos(0, std::ios::in);
                   inp = new char[size+1];
                   assert(inp);
                   buffer->sgetn(inp, size);
                   n = size;
                   inp[n] = 0;
                 }
                 break;
      case ':' :
                 {
                   std::ostringstream os;
                   os << "Missing argument of " << char(optopt);
                   throw gapc::OptException(os.str());
                 }
      case '?' :
      default:
                 {
                   std::ostringstream os;
                   os << "Unknown Option: " << char(o);
                   throw gapc::OptException(os.str());
                 }
    }
  }
  if (!inp) {
    if (optind != argc-1)
      if (optind<argc-1)
        throw gapc::OptException("Spurious arguments/options.");
      else
        throw gapc::OptException("Missing input sequence or no -f.");
    inp = argv[argc-1];
    n = strlen(inp);
    inp = new char[n+1];
    strcpy(inp, argv[argc-1]);
  }
  if (opt.window_mode) {
    if (opt.window_size > n)
      throw gapc::OptException("Window Size > input sequence");
    if (opt.window_size <= 6)
      throw gapc::OptException("Window Size too small (> 6)");
  } else {
    opt.window_size = n;
  }

  gapc::class_name obj;

  //obj.init(inp, n);
  //obj.cyk();
  gapc::Opts opts;
  opts.window_mode = true;
  opts.window_size = opt.window_size;
  opts.window_increment = opt.window_inc;
  opts.inputs.push_back(std::make_pair(inp, n));
  obj.init(opts);


  //
  //
  //

  std::cout << "# window_i window_j subword_i subword_j shape prob mfe structure\n";
  for (size_t i = 0; i+opt.window_size <= n; ++i) {
    for (size_t j = i + 6; j <= i + opt.window_size; ++j) {
        output(obj, i, j, opt);
    }
    obj.window_increment();
  }

  //
  //
  //

  /*

  std::cout << "Window " << 0 << " " << opt.window_size << '\n';
  if (all_subwords) {
    for (size_t a = 0; a < opt.window_size; ++a)
      for (size_t b = a + 6; b <= opt.window_size; ++b) {
        std::cout << "Subword " << a << ' ' << b << '\n';
        output(obj, a, b, opt);
      }
  } else {
   output(obj, 0, opt.window_size, opt);
  }

  if (opt.window_size >= n)
    return 0;

  // FIXME support opt.window_inc > 1
 
  obj.window_increment();
  if (all_subwords) {
    for (size_t i = opt.window_inc; ; i+=opt.window_inc) {
      size_t b = std::min(i + opt.window_size, n);
      std::cout << "Window " << i << " " << b << '\n';
      for (size_t a = i; a < i+opt.window_size-6; ++a) {
        std::cout << "Subword " << a << ' ' << b << '\n';
        output(obj, a, b, opt);
      }
      if (i+opt.window_size >= n)
        break;
      obj.window_increment();
    }
  } else {
    for (size_t i = opt.window_inc; ; i+=opt.window_inc) {
      size_t b = std::min(i + opt.window_size, n);
      std::cout << "Window " << i << " " << b << '\n';
      size_t a = i;
      output(obj, a, b, opt);
      if (i+opt.window_size >= n)
        break;
      obj.window_increment();
    }
  }
  */

  return 0;
}
