/* {{{

    This file is part of gapc (GAPC - Grammars, Algebras, Products - Compiler;
      a system to compile algebraic dynamic programming programs)

    Copyright (C) 2008-2011  Georg Sauthoff
         email: gsauthof@techfak.uni-bielefeld.de or gsauthof@sdf.lonestar.org

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

}}} */


#ifndef GRAMMAR_HH
#define GRAMMAR_HH

#include <string>
#include <list>
#include "hashtable.hh"

#include "runtime.hh"
#include "loc.hh"

#include "terminal.hh"

#include "symbol_fwd.hh"
#include "printer_fwd.hh"

class Arg;
class Signature;
class Signature_Base;
class Visitor;
class AST;

class Grammar {
  private:
    AST &ast;
    Runtime::Asm::Poly asm_rt;

    std::list<Symbol::NT*> ordering;

    std::list<Symbol::NT*> nt_list;
    std::list<Symbol::NT*> new_nts;

    void renumber_nts();
    void move_new_nts();
  public:
    std::string *name;
    std::string *sig_name;
    std::string *axiom_name;
    Loc axiom_loc;
    Loc location;
    // temp list
    hashtable<std::string, Arg*> tab_names;

    hashtable<std::string, Symbol::Base*> NTs;
    hashtable<std::string, Symbol::NT*> tabulated;
    Symbol::NT* axiom;


    Grammar(AST &as, std::string *n, std::string *s, std::string *a, const Loc &l)
      : ast(as),  name(n), sig_name(s), axiom_name(a), location(l),
        axiom(NULL)
    {
      Terminal::add_predefined(*this);
    }

    void add_nt(Symbol::NT *nt);
    void add_nt_later(Symbol::NT *nt);
    const std::list<Symbol::NT*> &nts() const { return nt_list; }

    size_t nt_number();

    bool init_tabulated();
    bool init_axiom();
    bool init_nt_links();

    bool remove_unreachable();

    void print_nts();
    void print_links();

    bool has_nonproductive_NTs();

    void init_table_dims();
    void window_table_dims();

    void init_calls();

    bool init_tracks();

    // FIXME
    //void normalize();
    // Grammar* getCFG(Algebra &canonical_alg);

    bool check_semantic();

    const Runtime::Asm::Poly & runtime_by_width();

    Runtime::Poly runtime();

    void clear_runtime();

    bool set_tabulated(std::vector<std::string> &v);
    void clear_tabulated();

    void init_in_out();
    void set_tabulated(hashtable<std::string, Symbol::NT*> &temp);
    void set_all_tabulated();
    Runtime::Poly asm_opt_runtime();
    void approx_table_conf(bool opt_const = true, unsigned int const_div = 5);
    void put_table_conf(std::ostream &s);
    void set_tabulated(Symbol::Base *nt);

    void init_self_rec();

    bool check_signature(Signature_Base &s);

    void print_type(std::ostream &s);

    void eliminate_lists();

    void reset_types();
    void init_list_sizes();

    void traverse(Visitor &v);

    void inline_nts();

    void init_indices();
    void print_indices();
    void init_guards();
    void print_guards();

    void init_decls();
    void init_decls(const std::string &prefix);

    void codegen(AST &ast);
    void print_code(Printer::Base &out);

    void print_dot(std::ostream &out);

    void dep_analysis();

    std::list<Symbol::NT*> & topological_ord() { return ordering; }

    // check if Alt::Simple term have const only args

    void remove(Symbol::NT *x);

    void init_multi_yield_sizes();
    void print_multi_ys() const;
    
    bool multi_detect_loops();

    void multi_propagate_max_filter();

};


#endif
