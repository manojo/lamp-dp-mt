#include <stdlib.h>
#include <stdio.h>


int main(int argc, char **argv)
{
  // test
  for (int i = 0; i < 23; ++i)
    printf("%d ", i);
  printf("\n");
  int j = 42;
  return 0;
}
