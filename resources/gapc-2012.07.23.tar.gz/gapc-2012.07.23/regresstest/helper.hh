#ifndef HELPER_HH
#define HELPER_HH

#include <math.h>
#include <cmath>

inline int myround(float d)
{
  return std::floor(d + 0.5);
}


#endif
