#!/bin/sh
set -e
ssh porta ssh azteca at -f /vol/gapc/src/adpc-tng_slave/at_install.sh now
