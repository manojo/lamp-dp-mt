/* {{{

    This file is part of gapc (GAPC - Grammars, Algebras, Products - Compiler;
      a system to compile algebraic dynamic programming programs)

    Copyright (C) 2008-2011  Georg Sauthoff
         email: gsauthof@techfak.uni-bielefeld.de or gsauthof@sdf.lonestar.org

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

}}} */


#include <iostream>
#include <string>
#include <vector>
#include <cassert>
#include <exception>

#include "instance.hh"
#include "product.hh"

#include "cpp.hh"

#include "driver.hh"

#include "log.hh"

#include "version.hh"

#include "options.hh"
#include "backtrack.hh"
#include "subopt.hh"
#include "kbacktrack.hh"

#include "subopt_marker.hh"

#include <memory>
#include <boost/program_options.hpp>
namespace po = boost::program_options;

static void version()
{
  std::cout << "gapc version " << gapc::version_id
    << std::endl << "  Copyright 2008-2011 Georg Sauthoff, GPL v3+"
    << std::endl << std::endl;
}

static void parse_options(int argc, char **argv, Options &rec)
{
  po::variables_map vm;
  po::options_description visible("Options");
  visible.add_options()
    ("help,h", "produce help message")
    ("inline,n", "try to inline NTs")
    ("instance,i",  po::value< std::string >(), "use instance (else first)" )
    ("product,p", po::value< std::string >(), "use product of algebras" )
    ("output,o", po::value< std::string >(), "output filename (out.cc)" )
    ("class-name", po::value< std::string >(), "default: basename(output)" )
    ("stdout,E", "print code to stdout")
    ("tab", po::value< std::vector<std::string> >(), "overwrite table conf with this list")
    ("table-design,t", "automatically compute optimal table configuration (ignore conf from source file)")
    ("tab-all", "tabulate everything")
    ("cyk", "bottom up evalulation codgen (default: top down unger style)")
    ("backtrace", "use backtracing for the pretty print RHS of the product")
    ("kbacktrace", "backtracing for k-scoring lhs")
    ("subopt-classify", "classified dp")
    ("subopt", "generate suboptimal backtracing code (needs foo * pretty)")
    ("sample", "generate stochastic backtracing code")
    ("no-coopt", "with kbacktrace, don't output cooptimal candidates")
    ("no-coopt-class", "with kbacktrace, don't output cooptimal candidates")
    ("window-mode,w", "window mode")
    ("kbest", "classify the k-best classes only")
    ("include,I", po::value< std::vector<std::string> >(), "include path")
    ("version,v", "version string")
    ;
  po::options_description hidden("");
  hidden.add_options()
    ("backtrack", "deprecated for --backtrace")
    ("kbacktrack", "deprecated for --kbacktrace")
    //("file", po::value<std::string>(&filename), "input file");
    ("file", po::value<std::string>(), "input file");
  po::positional_options_description pd; pd.add("file", 1);
  po::options_description opts;
  opts.add(hidden).add(visible);

  po::store(po::command_line_parser(argc, argv).options(opts)
        .positional(pd).run(), vm);

  po::notify(vm);

  if (vm.count("help")) {
    version();
    std::cout << "Usage: " << *argv << " (OPTION)* FILE\n\n";
    std::cout << visible << std::endl;
    std::exit(0);
  }

  if (vm.count("version")) {
    version();
    std::exit(0);
  }

  if (!vm.count("file")) {
    std::cerr << "No filename specified." << std::endl;
    std::exit(1);
  }
  rec.in_file = vm["file"].as<std::string>();
  if (vm.count("instance"))
    rec.instance = vm["instance"].as<std::string>();
  if (vm.count("product"))
    rec.product = vm["product"].as<std::string>();

  if (vm.count("output"))
    rec.out_file = vm["output"].as<std::string>();
  else
//    rec.out_file = basename(rec.in_file) + ".cc";
    rec.out_file = "out.cc";
  rec.header_file = basename(rec.out_file) + ".hh";
  rec.make_file = basename(rec.out_file) + ".mf";

  if (vm.count("class-name"))
    rec.class_name = vm["class-name"].as<std::string>();
  else
    rec.class_name = classname(rec.out_file);

  if (vm.count("stdout"))
    rec.out_file.clear();

  if (vm.count("inline"))
    rec.inline_nts = true;

  if (vm.count("table-design"))
    rec.approx_table_design = true;
  if (vm.count("tab-all"))
    rec.tab_everything = true;
  if (vm.count("tab"))
    rec.tab_list = vm["tab"].as< std::vector<std::string> >();
  if (vm.count("include"))
    rec.includes = vm["include"].as<std::vector<std::string> >();
  if (vm.count("cyk"))
    rec.cyk = true;
  if (vm.count("backtrack") || vm.count("backtrace") || vm.count("sample"))
    rec.backtrack = true;
  if (vm.count("sample"))
    rec.sample = true;
  if (vm.count("subopt"))
    rec.subopt = true;
  if (vm.count("kbacktrack") || vm.count("kbacktrace"))
    rec.kbacktrack = true;
  if (vm.count("no-coopt"))
    rec.no_coopt = true;
  if (vm.count("no-coopt-class"))
    rec.no_coopt_class = true;
  if (vm.count("subopt-classify"))
    rec.classified = true;
  if (vm.count("window-mode"))
    rec.window_mode = true;
  if (vm.count("kbest"))
    rec.kbest = true;

  bool r = rec.check();
  if (!r)
    throw LogError("Seen improper option usage.");
}

class Main {
  private:
    int argc;
    char **argv;

    Log log;
    Options opts;
    Driver driver;

    Code::Gen code_;


    void conv_classified_product(Options &opts)
    {
      Instance *instance = driver.ast.instance(opts.instance);
      if (!instance)
        return;
      bool r = instance->replace_classified_product();
      if (r)
        opts.classified = true;
    }

  public:
    Main(int a, char **v)
      : argc(a), argv(v)
    {
    }

    void front()
    {
      parse_options(argc, argv, opts);

      driver.setFilename(opts.in_file);
      driver.set_includes(opts.includes);

      driver.parse();
      driver.ast.select_grammar(opts.instance);
      driver.parse_product(opts.product);

      if (driver.is_failing())
        throw LogError("Seen parse errors.");

      Grammar *grammar = driver.ast.grammar();
      bool r = grammar->check_semantic();
      if (!r)
        throw LogError("Seen semantic errors.");

      driver.ast.set_window_mode(opts.window_mode);
      driver.ast.kbest = opts.kbest;

      if (opts.cyk)
        driver.ast.set_cyk();

      if (opts.tab_everything)
        grammar->set_all_tabulated();
      if (!opts.tab_list.empty()) {
        grammar->clear_tabulated();
        grammar->set_tabulated(opts.tab_list);
      }
      if (opts.approx_table_design)
        grammar->approx_table_conf();
      driver.ast.warn_user_table_conf_suboptimal();

      driver.ast.derive_temp_alphabet();

      r = driver.ast.check_signature();
      if (!r)
        throw LogError("Seen signature errors.");
      r = driver.ast.check_algebras();
      if (!r)
        throw LogError("Seen algebra errors.");
      driver.ast.derive_roles();
    }

    void back(Instance *i = 0, Instance *instance_buddy = 0)
    {
      Instance *instance = i;
      if (!i || instance_buddy) {
        if (opts.backtrack || opts.subopt || opts.kbacktrack) {
          instance = driver.ast.split_instance_for_backtrack(opts.instance);
        } else {
          instance = driver.ast.instance(opts.instance);
          if (instance) {
            bool r = driver.ast.check_instances(instance);
            if (!r)
              throw LogError("Instance checks failed.");
          }
          if (instance && instance->product->contains(Product::OVERLAY))
            LogError("Overlay product '|' only make sense with --backtrack");
        }
        if (!instance)
          throw LogError("Seen instance errors.");
      }
      driver.ast.update_seq_type(*instance);

      if (opts.no_coopt)
        driver.ast.instance_->product->set_no_coopt();
      if (opts.no_coopt_class)
        driver.ast.instance_->product->set_no_coopt_class();

      bool r = driver.ast.insert_instance(instance);
      if (!r)
        throw LogError(
            "Instance inserting errors.");

      driver.ast.check_backtrack(opts);

      driver.ast.instance_grammar_eliminate_lists(instance);
      Grammar *grammar = driver.ast.grammar();
      grammar->init_list_sizes();
      driver.ast.warn_missing_choice_fns(instance);
      if (opts.inline_nts)
        grammar->inline_nts();
      grammar->init_indices();
      grammar->init_decls();
      // for cyk
      grammar->dep_analysis();


      driver.ast.codegen();

      instance->codegen();

      driver.ast.optimize_choice(*instance);
      driver.ast.optimize_classify(*instance);
      driver.ast.set_class_name(opts.class_name);


      Printer::Cpp hh(driver.ast, opts.h_stream());
      hh.set_argv(argv, argc);
      hh.class_name = opts.class_name;
      hh.header(driver.ast);
      hh.begin_fwd_decls();
      driver.ast.print_code(hh);
      instance->print_code(hh);
      hh.footer(driver.ast);
      hh.end_fwd_decls();
      hh.header_footer(driver.ast);

      Printer::Cpp cc(driver.ast, opts.stream());
      cc.set_argv(argv, argc);
      cc.class_name = opts.class_name;
      cc.set_files(opts.in_file, opts.out_file);
      cc.prelude(opts, driver.ast);
      cc.imports(driver.ast);
      driver.ast.print_code(cc);
      instance->print_code(cc);
      cc.footer(driver.ast);

      Code::Gen code(driver.ast);
      code_ = code;

      std::auto_ptr<Backtrack_Base> bt;
      if (opts.backtrack)
        bt = std::auto_ptr<Backtrack_Base>(new Backtrack());
      else if (opts.subopt)
        bt = std::auto_ptr<Backtrack_Base>(new Subopt());
      else if (opts.kbacktrack)
        bt = std::auto_ptr<Backtrack_Base>(new KBacktrack());
      else if (opts.classified)
        bt = std::auto_ptr<Backtrack_Base>(new Subopt_Marker());
      if (bt.get()) {
        driver.ast.backtrack_gen(*bt);
        bt->print_header(hh, driver.ast);
        bt->print_body(cc, driver.ast);
      }

      hh.backtrack_footer(driver.ast);

      hh.close_class();
    }

    void finish()
    {
      Printer::Cpp hh(driver.ast, opts.h_stream());
      hh.class_name = opts.class_name;
      hh.typedefs(code_);
    }

    void makefile()
    {
      Printer::Cpp mm(driver.ast, opts.m_stream());
      mm.set_argv(argv, argc);
      mm.makefile(opts);
    }

    void run()
    {
      front();
      makefile();

      conv_classified_product(opts);

      if (opts.classified) {
        std::string class_name = opts.class_name;
        bool kbacktrack = opts.kbacktrack;
        opts.kbacktrack = false;
        opts.class_name += "_buddy";

        std::pair<Instance*, Instance*> r =
          driver.ast.split_classified(opts.instance);
        back(r.first);

        // FIXME init marker code in buddy ...

        opts.cyk = false;
        opts.class_name = class_name;
        opts.classified = false;
        opts.kbacktrack = kbacktrack;
        driver.ast.check_instances(r.second);
        Code::Mode mode;
        mode.set_subopt_buddy();
        driver.ast.set_code_mode(mode);

        back(r.second, r.first);
      } else {
        back();
      }
      finish();
    }
};

int main(int argc, char **argv)
{
  Main m(argc, argv);
  try {
    m.run();
  } catch (std::exception &e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
  return 0;
}

