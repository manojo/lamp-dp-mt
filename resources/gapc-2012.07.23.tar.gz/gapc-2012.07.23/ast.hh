/* {{{

    This file is part of gapc (GAPC - Grammars, Algebras, Products - Compiler;
      a system to compile algebraic dynamic programming programs)

    Copyright (C) 2008-2011  Georg Sauthoff
         email: gsauthof@techfak.uni-bielefeld.de or gsauthof@sdf.lonestar.org

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

}}} */


#ifndef AST_H
#define AST_H

#include <list>
#include <string>
#include <sstream>
#include <ostream>

#include <set>

#include "hashtable.hh"

#include "log.hh"
#include "loc.hh"
#include "yieldsize.hh"
#include "grammar.hh"
#include "symbol.hh"
#include "type.hh"

#include "fn_decl.hh"

#include "algebra.hh"

#include "input.hh"

#include "codegen.hh"

#include "bool.hh"

#include "expr_fwd.hh"
#include "statement_fwd.hh"
#include "printer_fwd.hh"

class Signature;
class Instance;
class Backtrack_Base;

class Options;


class Import {

  private:

  public:
    std::string *name;
    Loc location;

    Import (std::string *s, const Loc &l) : name(s) { location = l; }

};

class Default {
  // FIXME

};


class AST {

  private:
    Code::Mode cg_mode;
    std::list<Statement::Hash_Decl*> hash_decls_;

    Product::Base *product_;

    std::list<Grammar*> *grammars_;
    Grammar *selected_grammar;

  public:
    AST();

    void set_product(Product::Base *p) { product_ = p; }
    Product::Base *product() { return product_; }

    std::list<Import*> imports;

    Input input;

    Signature *signature;

    hashtable<std::string, Algebra*> algebras;
    std::set<std::string> algebra_seen;

    void set_grammars(std::list<Grammar*> *);
    bool grammar_defined(const std::string &n) const;
    Grammar *grammar() const { assert(selected_grammar); return selected_grammar; }
    Grammar *grammar(const std::string&);
    void select_grammar(const std::string &instname);



    hashtable<std::string, Instance*> instances;
    Instance *first_instance;
    Instance *instance_;

    hashtable<std::string, Type::Base*> types;
    std::list<Type::Base*> type_def_list;

    hashtable<std::string, Fn_Decl*> filters;

    std::vector<Statement::Var_Decl*> seq_decls;

    Type::Base *get_type(const std::string &name, const Loc &l);
    Type::Base *get_type(const std::string &name);
    void add_type(std::string *name, const Loc &l, Type::Base *base);
    void add_sig_types(hashtable<std::string, Arg*> & args, Signature *s);

    bool check_signature();

    bool check_algebras();

    bool check_instances(Instance *instance);

    void print_instances(std::ostream &s);

    Instance *instance(const std::string &n);
    bool insert_instance(std::string &n);
    bool insert_instance(Instance *inst);
    bool instance_grammar_eliminate_lists(std::string &n);
    bool instance_grammar_eliminate_lists(Instance *inst);
    void warn_missing_choice_fns(Instance *instance);
    void warn_missing_choice_fns();
    void warn_user_table_conf_suboptimal();

    void codegen();

    void print_code(Printer::Base &out);

    void derive_roles();

    void optimize_choice(Instance &i);
    void optimize_classify(Instance &i);

    // FIXME probably remove these get/setters
    bool cyk() const { return cg_mode == Code::Mode::CYK; }
    void set_cyk() { cg_mode = Code::Mode::CYK; }

    bool backtrace() const { return cg_mode == Code::Mode::BACKTRACK; }
    void set_backtrace(bool b = true) { cg_mode = Code::Mode::BACKTRACK; }

    const Code::Mode & code_mode() const { return cg_mode; }

    void set_code_mode(const Code::Mode &m) { cg_mode = m; }

  private:
    // FIXME
    Product::Base *backtrack_product;
    Filter *backtrack_filter;
    Product::Two *original_product;
  public:
    Instance *split_instance_for_backtrack(std::string &n);
    std::pair<Instance*, Instance*> split_classified(const std::string &n);
    void backtrack_gen(Backtrack_Base &bt);

    void warn_unused_fns(Instance &i);

    void check_backtrack(const Options &opts);

    const std::list<Statement::Hash_Decl*> &hash_decls() const
    { return hash_decls_; }

    void set_class_name(const std::string &n);

  private:
    Type::Base *char_type;
     void update_alphabet_types(Type::Base *res);
  public:
    void derive_temp_alphabet();
    void update_seq_type(Instance &i);

  private:
    void set_tracks();

  public:
    Bool window_mode;
    void set_window_mode(bool w);

    Bool kbest;

    std::list<std::pair<Filter*, Expr::Fn_Call*> > sf_filter_code;
};



#endif
