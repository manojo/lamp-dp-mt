/* {{{

    This file is part of gapc (GAPC - Grammars, Algebras, Products - Compiler;
      a system to compile algebraic dynamic programming programs)

    Copyright (C) 2008-2011  Georg Sauthoff
         email: gsauthof@techfak.uni-bielefeld.de or gsauthof@sdf.lonestar.org

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

}}} */


#include "log.hh"

#include <algorithm>

Log::Log ()
 : seen_errs(false), debug_mode(false), error_count(0),
   out(&std::cerr)
{
  self = this;
}

Log::~Log() {}

void Log::inc_error()
{
  seen_errs = true;
  error_count++;
  if (error_count == 20)
    throw LogThreshException();
}

void Log::error(const std::string &m)
{
  inc_error();
  *out << "Error:" << std::endl << m << std::endl;
}

void Log::build_mark(const Loc& l, std::string &s)
{
  // vanilla bison 2.3 counts columns from 0
  // with sed hack in makefiles/lexyaccxx.mf from 1
  size_t off = l.begin.column;
  if (off)
    off -= 1; // bison 2.4 counts columns from 1
  std::string t(off, ' ');
  size_t length = 0;
  if (l.end.line == l.begin.line)
    length = l.end.column - l.begin.column;
  else
    length = 3;
  length = std::min(length, size_t(160));
  if (length > 1) {
    std::string fill(length, '-');
    fill[0] = '^';
    fill[length-1] = '^';
    s = t + fill;
    return;
  }
  std::string fill("^");
  s = t + fill;
}

void Log::msg(const Loc &l, const std::string &m, bool error)
{
  if (error) {
    inc_error();
    *out << "Error: ";
  } else {
    *out << "Warning: ";
  }
  *out << std::endl;
  if (!l.begin.filename) {
    *out << "<builtin>: " << m << std::endl;
    return;
  }
  build_message(*out, l, m);
}

void Log::msg_continue(const Loc &l, const std::string &m, bool error)
{
  if (error)
    inc_error();
  *out << std::endl;
  if (!l.begin.filename) {
    *out << "<builtin>: " << m << std::endl;
    return;
  }
  build_message(*out, l, m);
}

void Log::error(const Loc& l, const std::string& m)
{
  msg(l, m, true);
}

void Log::error_continue(const Loc& l, const std::string& m)
{
  msg_continue(l, m, true);
}

void Log::warning(const Loc& l, const std::string& m)
{
  msg(l, m, false);
}

void Log::build_message(std::ostream &out, const Loc &l,
    const std::string &m)
{
  if (!l.begin.filename) {
    out << m << std::endl;
    return;
  }
  std::string line;
  if (*l.begin.filename == "_PRODUCT_")
    line = product_;
  else
    line = l.line();

  out << line << std::endl;
  std::string mark;
  build_mark(l, mark);
  out << mark << std::endl;
  out << l << ": " << m << std::endl;
}

void Log::warning(const std::string& m)
{
  *out << "Warning: " << std::endl;
  *out << m << std::endl;
}

Log *Log::self;

#include <sstream>

LogError::LogError(const Loc &l, std::string m)
{
  std::ostringstream o;
  o << "Error: \n";
  Log t;
  t.build_message(o, l, m);
  msg = o.str();
}

