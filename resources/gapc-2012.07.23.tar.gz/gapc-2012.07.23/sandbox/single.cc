

void foo();
void bar();

int main()
{
  foo();
  bar();
  return 0;
}
