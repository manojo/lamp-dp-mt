{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE NoMonomorphismRestriction #-}

-- RNAfold combinators, extracted for quickcheck

module Tests.Comb
  ( (~~#)
  , (#~~)
  , (~~##)
  , (##~~)
  ) where

import Data.Array.Repa.Index
import qualified Data.Vector.Fusion.Stream as S
import Test.QuickCheck
import Test.QuickCheck.All
import Data.List

import qualified ADP.Legacy as L
import qualified ADP.Fusion as F
import qualified ADP.Fusion.Monadic as M
import qualified ADP.Fusion.Monadic.Internal as F
import ADP.Fusion.Monadic (makeLeftCombinator)
import ADP.Fusion.Monadic.Internal (Box(..))

import ADP.Fusion.QuickCheck hiding (options,customCheck,allProps)



options = stdArgs {maxSuccess = 1000}

customCheck = quickCheckWithResult options

allProps = $forAllProperties customCheck

infixl 9 #~~, ~~#, ##~~, ~~##

(##~~) = makeLeftCombinator 1 27
{-# INLINE (##~~) #-}

(~~##) xs ys = Box xs mk step ys where
  minT = 4  -- minimal total size of region
  minC = 1  -- minimal number of nuc's on the right
  maxC = 28
  {-# INLINE mk #-}
  mk (z:.k:.j,a,b) = let (_:.i) = z
                         cnsmd = k-i -- consumed part
                         l = max k (j-maxC+cnsmd)
                     in return (z:.k:.l:.j,a,b)
  {-# INLINE step #-}
  step (z:.k:.l:.j,a,b)
    | l<=j-(max 0 $ minT - cnsmd) && l+minC<=j
    = return $ S.Yield (z:.k:.l:.j,a,b) (z:.k:.l+1:.j,a,b)
    | otherwise = return $ S.Done
    where cnsmd = k-i
          (_:.i) = z
{-# INLINE (~~##) #-}

-- | The structure on the left is a subword with size 2-28. The maximal size
-- could be 30 but since the two combinators are linked, 29,30 would fail
-- anyways.

(#~~) = makeLeftCombinator 2 28
{-# INLINE (#~~) #-}

-- | The structure on the right is a subword with size 2-30, however we inspect
-- the stack an reduce the maximal size.

(~~#) xs ys = Box xs mk step ys where
  minT = 6  -- minimal total size of region
  minC = 2  -- minimal number of nuc's on the right
  maxC = 30
  {-# INLINE mk #-}
  mk (z:.k:.j,a,b) = let (_:.i) = z
                         cnsmd = k-i -- consumed part
                         l = max k (j-maxC+cnsmd)
                     in return (z:.k:.l:.j,a,b)
  {-# INLINE step #-}
  step (z:.k:.l:.j,a,b)
    | l<=j-(max 0 $ minT - cnsmd) && l+minC<=j
    = return $ S.Yield (z:.k:.l:.j,a,b) (z:.k:.l+1:.j,a,b)
    | otherwise = return $ S.Done
    where cnsmd = k-i
          (_:.i) = z
{-# INLINE (~~#) #-}



-- * property checking

fCombined (i,j) = S.toList $ (,,) F.<<< fRegion #~~ fRegion ~~# fRegion F.... id $ Z:.i:.j

bCombined (i,j) = [ ( (i,k),(k,l),(l,j) )
                  | k <- [i..j]
                  , l <- [k..j]
                  , k-i >= 2
                  , j-l >= 2
                  , (k-i) + (j-l) >= 6
                  , (k-i) + (j-l) <= 30
                  ]

prop_Combined (Small i, Small j) = fCombined (i,j) == bCombined (i,j)

fCombinedC (i,j) = S.toList $ (,,) F.<<< fRegion ##~~ fRegion ~~## fRegion F.... id $ Z:.i:.j

bCombinedC (i,j) = [ ( (i,k),(k,l),(l,j) )
                   | k <- [i..j]
                   , l <- [k..j]
                   , k-i >= 1
                   , j-l >= 1
                   , (k-i) + (j-l) >= 4
                   , (k-i) + (j-l) <= 28
                   ]

prop_CombinedC (Small i, Small j) = fCombinedC (i,j) == bCombinedC (i,j)

