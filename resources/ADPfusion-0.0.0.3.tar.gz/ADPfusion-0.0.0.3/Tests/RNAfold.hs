
-- | Simple wrapper around STrnafold

module Main where

import Tests.STrnafold



main = do
  xs <- fmap lines getContents
  mapM_ (print . testRNAfold) xs
