
module Main where

import Criterion.Main
import Criterion.Config

-- import Data.TypeLevel
-- import qualified Tests

-- import qualified Nussinov as SF
-- import qualified ADPnussinov as ADP
import qualified Tests.STnussinov as ST
import qualified Tests.STrnafold as ST



input = concat $ repeat
  "CCACCCCAACGACUCGGCCGGGAAGAUUACUUUCGGACUCAUUGAGGUCAUAACGAUUACCCCGACGGUUCCUGCCGAGAGUGAGGCGUUCGGAGAGCAUGGGUGACCGCUGCUACUUCAAUUACUGCGUGCUCGUUCGUUUUGACCCCUGUAUAUAACUCCGGAGGCAGGCGUCACAGACGCUUUUCAGGUCGGGCGCUGAGGCCUAUUGCUAGACUUUUGUCGUCCUAGUGGGACUGCACACUAUGAAGCAUAUAUGCACGACGGUUCGCAAACGCCAGCGAGACAAAUGUGAGGUUGGUCACGUACGGCAGGAUCCCUGCAGUUCAACAAAGUAUCGGACAACGCUCAAAUCAUGUCAGGGUGGCGCCGUUAAGAUUGAAACUGGUGACGAAUAACAUAAUCGCAUGCUAUCGACGCCAUAGCCUUACACGCAGAGUUAACCUCGCACAGGGCCAGGGCUCCGGAUGCAAGUGUCGGUCUUAUGUCGGAAUUUUUCAGUGAUGAACAUGGAUACGCUGCCAGGAGGUAGAUACUCGGUUGUCUCAUUCGGAACUGCUGUUAACGCAGCAUCCGCUAGAGGAAUUCUGGUGUAACAGUACCCUUCGAUGGUCAAGAUUAGUAUCCGUCGCACACGUCAAAAAUCGUUUACUCGUACUCAUAGCGACUUGACAGGUGUAUAGUUGAACCUUCAUAACUACUGAAGUCGAGUGGAGGGACACGUUUCACGGAGGGAGUUGAUUAUAAUAGGGAGUCGGUCCUUCUUUUUAUCAUUCCACUACGGAUAAGCUCCAAGCCGGUUCCACUUUGUCCUAUAGCACGUAACUGAUGAAAUCUAGAAUUGACUCCCUUCUCGGGGUUGCAAGUCUUUCUUCCGCAAAACUCAUCUUGAGCGAAUGCUUAAAGUUCACUGAACGAAUCUACGAGAAGUCUAUAAACUGAAGGGCGAGGGUACUGCAACCUCUAUCCGGCAAAAUUACUACAGUACGGUACUUCCAAA"

cfg = defaultConfig
        { cfgSamples = ljust 5
        }

main = do
  defaultMainWith cfg (return ())
    [ bgroup "vienna"
        [ bench "100" $ nf (\k -> ST.testRNAfold $ take k input) 100
        , bench "1000" $ nf (\k -> ST.testRNAfold $ take k input) 1000
        ]
  {-
    , bgroup "extvie"
        [ bench  "100" $ nf (\k -> ST.testRNAfold $ take k input)  100
        , bench  "200" $ nf (\k -> ST.testRNAfold $ take k input)  200
        , bench  "300" $ nf (\k -> ST.testRNAfold $ take k input)  300
        , bench  "400" $ nf (\k -> ST.testRNAfold $ take k input)  400
        , bench  "500" $ nf (\k -> ST.testRNAfold $ take k input)  500
        , bench  "600" $ nf (\k -> ST.testRNAfold $ take k input)  600
        , bench  "700" $ nf (\k -> ST.testRNAfold $ take k input)  700
        , bench  "800" $ nf (\k -> ST.testRNAfold $ take k input)  800
        , bench  "900" $ nf (\k -> ST.testRNAfold $ take k input)  900
        , bench "1000" $ nf (\k -> ST.testRNAfold $ take k input) 1000
        ] -}
    , bgroup "nussinov"
          -- do NOT just ask for whnf, this only tells you that we get a list back!!!
          -- ask for the normal form, which evaluates completely...
        [ bench "100"   $ nf (\k -> ST.testNussinov $ take k input) 100
        , bench "1000"  $ nf (\k -> ST.testNussinov $ take k input) 1000
        ]
    ]
