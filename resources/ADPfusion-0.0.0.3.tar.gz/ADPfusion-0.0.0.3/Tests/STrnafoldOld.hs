{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE FunctionalDependencies #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE RecordWildCards #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE TypeSynonymInstances #-}
{-# LANGUAGE UndecidableInstances #-}

module Tests.STrnafold where

import Control.Monad.ST
import Control.Monad
import Control.Monad.Primitive
import Data.Array.Repa.Index
import Data.Array.Repa.Shape
import qualified Data.Vector.Unboxed as VU
import qualified Data.Vector.Fusion.Stream.Monadic as S

import Data.PrimitiveArray as PA
import Data.PrimitiveArray.Unboxed.Zero as PA
import ADP.Fusion.Monadic
import ADP.Fusion.Monadic.Internal
import Biobase.Primary
import Biobase.Secondary.Vienna
import Biobase.Vienna
import Biobase.Vienna.Default

import Debug.Trace




-- test = runST (rnaFold (fst turnerRNA2004) $ mkPrimary "CCCAAAGGG") -- "CCCAAAGGGCCCAAAGGG")

testRNAfold :: String -> Int
testRNAfold inp = runST (rnaFold iloopT' (fst turnerRNA2004) . mkPrimary $ inp)
{-# NOINLINE testRNAfold #-}

type IT m = Vienna2004 -> Int -> Int -> Int -> m Int

iloopT' :: Monad m => IT m -- Vienna2004 -> Int -> Int -> Int -> m Int
iloopT' Vienna2004{..} = go where
  go llen w rlen = return $ w + iloopL!(Z:.len) where len = llen+rlen
{-# INLINE iloopT' #-}

-- lets do rna-folding (starting with pairmax)
--
-- NOTE type annotations are NOT required for functions that are actually
-- /used/. We provide them (i) as a guide for the user and (ii) so that we can
-- selectively comment some of them out.

rnaFold :: IT (ST s) -> Vienna2004 -> Primary -> (ST s) Int
rnaFold iloopT' ener@Vienna2004{..} inp = do
  let iloopT = iloopT' ener
      {-# INLINE iloopT #-}
  let n = let (_,Z:.l) = bounds inp in l+1
  let inpv = VU.fromList $ toList inp
      {-# NOINLINE inpv #-}
  let base :: DIM2 -> ST s (Scalar Nuc)
      base = base' inp
      {-# INLINE base #-}
  let baselR :: DIM2 -> ST s (Scalar (Nuc,Nuc))
      baselR = baselR' inp
      {-# INLINE baselR #-}
  let baseLr :: DIM2 -> ST s (Scalar (Nuc,Nuc))
      baseLr = baseLr' inp
      {-# INLINE baseLr #-}
  let region :: DIM2 -> ST s (Scalar (VU.Vector Nuc))
      region = region' inpv
      {-# INLINE region #-}
  let reglen = reglen' inp
      {-# INLINE reglen #-}
  let regXx :: DIM2 -> ST s (Scalar (Nuc,Nuc,Int))
      regXx = regXx' inp
      {-# INLINE regXx #-}
  let regxX :: DIM2 -> ST s (Scalar (Nuc,Nuc,Int))
      regxX = regxX' inp
      {-# INLINE regxX #-}

  let h = S.foldl' min (999999::Int)
      {-# INLINE h #-}
  let hS = fmap Scalar . S.foldl' min (999999::Int)
      {-# INLINE hS #-}

  -- | TODO tabulated hairpins of certain length
  -- | TODO hairpins of size > 30
  let hairpinF :: (Nuc,Nuc) -> (VU.Vector Nuc) -> (Nuc,Nuc) -> ST s Int
      hairpinF (l,lp) reg (rp,r)
        | len <  3  = return 999999
        | len > 31  = return 999999
        | otherwise = return $ hairpinL!(Z:.len) -- + hairpinMM!(Z:.p:.lp:.rp)
        where p   = mkViennaPair (l,r)
              len = VU.length reg
      {-# INLINE hairpinF #-}
  -- | NOTE len>30 should not be needed with specialized combinators making sure of this!
  let iloopF :: (Nuc,Nuc) -> Int -> Int -> Int -> (Nuc,Nuc) -> ST s Int
      iloopF (l,lp) llen w rlen (rp,r)
--        | len > 30  = return 999999
        | otherwise = return $ w + iloopMM!(Z:.op:.lp:.rp) + iloopL!(Z:.len)
        where op  = mkViennaPair (l,r)
              len = llen+rlen
      {-# INLINE iloopF #-}
  let miloopF :: (Nuc,Nuc,Int) -> Int -> (Nuc,Nuc,Int) -> ST s Int
      miloopF (l,lp,llen) w (rp,r,rlen)
        | otherwise = return $ w + iloopMM!(Z:.op:.lp:.rp) + iloopL!(Z:.len)
        where op  = mkViennaPair (l,r)
              len = llen+rlen
      {-# INLINE miloopF #-}
  let iloopIF :: Int -> Int -> Int -> ST s Int
      iloopIF llen w rlen = return $ w + iloopL!(Z:.len) where len = llen+rlen
      {-# INLINE iloopIF #-}
  let iloopOF :: (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> ST s Int
      iloopOF (l,lp) iloopif (rp,r) = return $ iloopif + iloopMM!(Z:.op:.lp:.rp) where op = mkViennaPair (l,r)
      {-# INLINE iloopOF #-}
  let stackF :: (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> ST s Int
      stackF (l,lp) w (rp,r) = return $ w + stack!(Z:.op:.ip)
        where op = mkViennaPair (l,r)
              ip = mkViennaPair (rp,lp)
      {-# INLINE stackF #-}
  let multiF :: (Nuc,Nuc) -> Int -> Int -> (Nuc,Nuc) -> ST s Int
      multiF (l,lp) b c (rp,r) = return $ b+c + multiMM!(Z:.p:.lp:.rp)
        where p = mkViennaPair (l,r)
      {-# INLINE multiF #-}
  let multiIF :: Int -> Int -> ST s Int
      multiIF b c = return $ b+c
      {-# INLINE multiIF #-}
  let multiOF :: (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> ST s Int
      multiOF (l,lp) multiif (rp,r) = return $ multiif + multiMM!(Z:.p:.lp:.rp) where p = mkViennaPair (l,r)
      {-# INLINE multiOF #-}
  let bulg1LF :: Nuc -> (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> ST s Int
      bulg1LF l (_,lp) w (rp,r) = return $ w + stack!(Z:.op:.ip)
        where op = mkViennaPair (l,r)
              ip = mkViennaPair (rp,lp)
      {-# INLINE bulg1LF #-}
  let bulg1RF :: (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> Nuc -> ST s Int
      bulg1RF (l,lp) w (rp,_) r = return $ w + stack!(Z:.op:.ip)
        where op = mkViennaPair (l,r)
              ip = mkViennaPair (rp,lp)
      {-# INLINE bulg1RF #-}
  let iloop11F :: Nuc -> (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> Nuc -> ST s Int
      iloop11F l (l',lp) w (rp,r') r = return $ w + iloop1x1!(Z:.op:.ip:.l':.r')
        where op = mkViennaPair (l,r)
              ip = mkViennaPair (rp,lp)
      {-# INLINE iloop11F #-}
  let iloop12F l (l',lp) w (rp,r'') r' r = return $ w + iloop2x1!(Z:.op:.ip:.l':.r'':.r')
        where op = mkViennaPair (l,r)
              ip = mkViennaPair (rp,lp)
      {-# INLINE iloop12F #-}
  let iloop21F l l' (l'',lp) w (rp,r') r = return $ w + iloop2x1!(Z:.op:.ip:.r':.l':.l'')
        where op = mkViennaPair (l,r)
              ip = mkViennaPair (rp,lp)
      {-# INLINE iloop21F #-}

  let iD = return . id
      {-# INLINE iD #-}
  let blkF reg w = return $ w
      {-# INLINE blkF #-}

  let bcF b c = return $ b + c
      {-# INLINE bcF #-}
  let bsF b reg = return $ b
      {-# INLINE bsF #-}

  let ssF reg = return $ 0
      {-# INLINE ssF #-}

  structT <- fromAssocsM zeroDim (Z:.n:.n) 0      []
  blockT  <- fromAssocsM zeroDim (Z:.n:.n) 999999 []
  compsT  <- fromAssocsM zeroDim (Z:.n:.n) 999999 []
  weakT   <- fromAssocsM zeroDim (Z:.n:.n) 999999 []

  let weak   ij = Scalar `fmap` readM weakT   ij
      {-# INLINE weak #-}
  let block  ij = Scalar `fmap` readM blockT  ij
      {-# INLINE block #-}
  let comps  ij = Scalar `fmap` readM compsT  ij
      {-# INLINE comps #-}

  let basepairing (Z:.i:.j) = tf
        where p  = mkViennaPair (inp!(Z:.i), inp!(Z:.j-1))
              tf = i>=0 && j>0 && i<n && j-1<n && p /= vpNS
      {-# INLINE basepairing #-}

  -- | tables need to be given in the order they are used, hence weak is up on
  -- top, as all other tables can have (i,j) dependencies in weak when
  -- calculating (i,j)

--      iloopF   <<< baseLr -~~ reglen #~~ weak ~~# reglen ~~- baselR |||
--      miloopF <<< regXx #~~ weak ~~# regxX |||
--      multiF   <<< baseLr -~~ block +~+ comps ~~- baselR            |||
  fillTables
    weakT (
      -- iloopOF <<< baseLr -~~ (iloopIF <<< reglen #~~ weak ~~# reglen ... hS) ~~- baselR |||
      iloopOF <<< baseLr -~~ (iloopT <<< reglen #~~ weak ~~# reglen ... hS) ~~- baselR |||
      bulg1LF <<< base -~~ baseLr -~~ weak ~~- baselR |||
      bulg1RF <<< baseLr -~~ weak ~~- baselR ~~- base |||
      iloop11F <<< base -~~ baseLr -~~ weak ~~- baselR ~~- base |||
      iloop12F <<< base -~~ baseLr -~~ weak ~~- baselR ~~- base ~~- base |||
      iloop21F <<< base -~~ base -~~ baseLr -~~ weak ~~- baselR ~~- base |||
      {-
      iloop22F <<< base -~~ base -~~ baseLr -~~ weak ~~- baselR ~~- base ~~- base |||
      iloop1nF <<< base -~~ baseLr -~~ weak ~~- baselR ~~# reglen ~~- baselR |||
      iloopn1F <<< baseLr -~~ reglen #~~ weak -~~ baseLr weak ~~- baselR ~~- base |||
      bulgeLF  <<< baseLr -~~ reglen #~~ baselR -~~ weak ~~- base |||
      bulgeRF  <<< base -~~ weak ~~- baseLr ~~# reglen ~~- baselR |||
      -}
      multiOF   <<< baseLr -~~ (multiIF <<< block +~+ comps ... hS) ~~- baselR            |||
      stackF   <<< baseLr -~~ weak     ~~- baselR                   |||
      hairpinF <<< baseLr -~~ region ~~- baselR                     ... h `with` basepairing)
    blockT (
      blkF <<< reglen +~+ weak |||
      iD   <<< weak            ... h)
    compsT (
      bcF <<< block +~+ comps  |||
      bsF <<< block +~+ reglen |||
      iD  <<< block            ... h)
    structT (
      ssF <<< reglen |||
      iD  <<< comps  ... h)

  ret <- readM structT (Z:.0:.n)
  return $ traceShow ret ret
{-# INLINE rnaFold #-}

infixl 5 `with`
with xs cond ij = if cond ij then xs ij else return 999999
{-# INLINE with #-}


region' :: Monad m => VU.Vector Nuc -> DIM2 -> m (Scalar (VU.Vector Nuc))
region' inp (Z:.i:.j) = return . Scalar $ VU.unsafeSlice i (j-i) inp
{-# INLINE region' #-}

reglen' :: Monad m => Primary -> DIM2 -> m (Scalar Int)
reglen' inp (Z:.i:.j) = return . Scalar $ j-i
{-# INLINE reglen' #-}

regXx' :: Monad m => Primary -> DIM2 -> m (Scalar (Nuc,Nuc,Int))
regXx' inp (Z:.i:.j) = return . Scalar $ (PA.index inp (Z:.0), PA.index inp (Z:.1), j-i)

regxX' :: Monad m => Primary -> DIM2 -> m (Scalar (Nuc,Nuc,Int))
regxX' inp (Z:.i:.j) = return . Scalar $ (PA.index inp (Z:.0), PA.index inp (Z:.1), j-i)

base' :: Monad m => Primary -> DIM2 -> m (Scalar Nuc)
base' inp (Z:.i:.j) = return . Scalar $ PA.index inp (Z:.i)
{-# INLINE base' #-}

-- | Nucleotide, second one to the right.

baseLr' :: Monad m => Primary -> DIM2 -> m (Scalar (Nuc,Nuc))
baseLr' inp (Z:.i:.j) = return . Scalar $ (PA.index inp (Z:.i), PA.index inp (Z:.i+1))

baselR' :: Monad m => Primary -> DIM2 -> m (Scalar (Nuc,Nuc))
baselR' inp (Z:.i:.j) = return . Scalar $ (PA.index inp (Z:.i-1), PA.index inp (Z:.i))

fillTables
  :: PrimMonad m
  => MArr0 (PrimState m) DIM2 Int -> (DIM2 -> m Int)
  -> MArr0 (PrimState m) DIM2 Int -> (DIM2 -> m Int)
  -> MArr0 (PrimState m) DIM2 Int -> (DIM2 -> m Int)
  -> MArr0 (PrimState m) DIM2 Int -> (DIM2 -> m Int)
  -> m ()
fillTables aT aF bT bF cT cF dT dF = do
  let (_,Z:.n:._) = boundsM aT
  forM_ [n,n-1 .. 0] $ \i -> forM_ [i..n] $ \j -> do
    let ij = Z:.i:.j
    aF ij >>= writeM aT ij
    bF ij >>= writeM bT ij
    cF ij >>= writeM cT ij
    dF ij >>= writeM dT ij
{-# INLINE fillTables #-}

-- * Specialized combinators for interior loops
--
-- The first one allows only 2-30 free nucleotides. The second one as well, but
-- is further restricted by what the first one already consumed. So if the
-- first consumed 5 nucleotides already, the second one consumes between 2-25
-- nucleotides.
--
-- Unfortunately, as the number of special cases grows, one has to start
-- resorting to writing them using 'Box' itself. But for this, we use one of
-- the existing 'make' functions.

infixl 9 #~~, ~~#

(#~~) = makeLeftCombinator 2 30
{-# INLINE (#~~) #-}

(~~#) xs ys = Box xs mk step ys where
  minC = 2
  maxC = 30
  {-# INLINE mk #-}
  mk (z:.k:.l,a,b) = let (_:.j) = z
                         cnsmd = k-j -- consumed part
                         k' = max k (l-maxC-cnsmd)
                     in return (z:.k:.k':.l,a,b)
  {-# INLINE step #-}
  step (z:.k:.x:.l,a,b)
    | x<=l-(max 0 $ minC - cnsmd)
    = return $ S.Yield (z:.k:.x:.l,a,b) (z:.k:.(x+1):.l,a,b)
    | otherwise = return $ S.Done
    where cnsmd = k-j
          (_:.j) = z
{-# INLINE (~~#) #-}
