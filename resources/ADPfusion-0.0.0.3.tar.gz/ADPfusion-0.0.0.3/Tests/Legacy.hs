
-- | Simple wrapper around STrnafold

module Main where

import Data.Char

import Tests.CanonicalRNA



main = do
  xs <- fmap lines getContents
  mapM_ (print . run . map toLower) xs
