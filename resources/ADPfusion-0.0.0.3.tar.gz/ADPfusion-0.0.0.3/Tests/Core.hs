{-# LANGUAGE NoMonomorphismRestriction #-}

-- | QuickCheck properties for a number of ADPfusion combinators.

module Tests.Core where

import Data.Array.Repa.Index
import Data.Vector.Fusion.Stream.Size
import Data.Vector.Fusion.Util
import Data.Vector.Fusion.Stream (Stream)
import qualified Data.Vector.Fusion.Stream as S
import qualified Data.Vector.Unboxed as VU
import Data.List

import ADP.Fusion
import qualified ADP.Fusion.Monadic as M
import qualified ADP.Fusion.Monadic.Internal as F



f :: Int -> Int -> Int -> Int
f a b c = a+b+c
{- INLINE f #-}

h :: Stream Int -> Int
h = S.foldl' (+) 0
{- INLINE h #-}

xs, ys, zs :: DIM2 -> Scalar Int
xs (Z:.i:.j) = Scalar $ i+j+23
ys (Z:.i:.j) = Scalar $ i+j+42
zs (Z:.i:.j) = Scalar $ i+j+123
{- INLINE xs #-}
{- INLINE ys #-}
{- INLINE zs #-}

stream :: Int -> Int -> Int
stream i j = f <<< xs +~+ ys +~+ zs ... h $ Z:.i:.j
{- INLINE stream #-}

theCore i j = stream i j
{-# NOINLINE theCore #-}
