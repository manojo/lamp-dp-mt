
-- | Simple wrapper around STrnafold

module Main where

import Tests.STnussinov



main = do
  xs <- fmap lines getContents
  mapM_ (print . take 1 . testNussinov) xs
