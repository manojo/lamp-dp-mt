{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE MultiParamTypeClasses #-}

-- | This module provides tests for monadic combinators. We need to be sure
-- that functions of 1 to many arguments can be combined in any way with "|||"
-- and "...".
--
-- Furthermore, it should (in general) be enough to import ADP.Fusion.Monadic
-- to get anything done.
--
-- TODO what about (ST s)?

module Tests.MC where

import Data.Array.Repa.Index
import qualified Data.Vector.Fusion.Stream.Monadic as S

import ADP.Fusion.Monadic
import ADP.Fusion.Monadic.Internal
import ADP.Fusion (Scalar(..))
import ADP.Fusion.Internal(Box(..), Fun(..))



-- ** these functions test 1-3 arguments in *any* monad

test01 :: (Monad m, Functor m) => m Int
test01 = fun1 <<< ints .#. summe $ ij

test02 :: (Monad m, Functor m) => m Int
test02 = fun2 <<< ints ~~~ ints .#. summe $ ij

test03 = fun3 <<< ints ~~~ doubles ~~~ ints .#. summe $ ij

-- ** different ways of having a choice

{-
test11 = fun1 <<< ints          |||
         fun2 <<< ints ~~~ ints .#. summe $ ij
-}

ints :: Monad m => DIM2 -> m (Scalar Int)
ints (Z:.i:.j) = return . Scalar $ j-i

doubles :: Monad m => DIM2 -> m (Scalar Double)
doubles (Z:.i:.j) = return . Scalar . fromIntegral $ j-i

summe :: Monad m => S.Stream m Int -> m Int
summe = S.foldl' (+) 0

ij :: DIM2
ij = Z:.1:.10

-- ** Functions with one or more parameters

fun1 :: Monad m => Int -> m Int
fun1 x = return $ x+1

fun2 :: Monad m => Int -> Int -> m Int
fun2 x y = return $ x+y

fun3 :: Monad m => Int -> Double -> Int -> m Int
fun3 x y z = return $ x + round y + z
