{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE TupleSections #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE RecordWildCards #-}

module Tests.STrnafold where

import Control.Monad
import Control.Monad.Primitive
import Control.Monad.ST
import Data.Array.Repa.Index
import qualified Data.Vector.Fusion.Stream.Monadic as S
import qualified Data.Vector.Fusion.Stream as P
import qualified Data.Vector.Unboxed as VU
import Control.Monad.State.Lazy
import Control.Arrow (first,second,(***))
import qualified Data.List as L

import Biobase.Primary
import Biobase.Secondary.Vienna

import Data.PrimitiveArray
import Data.PrimitiveArray.Unboxed.Zero

import ADP.Fusion.Monadic
import ADP.Fusion.Monadic.Internal

import Debug.Trace
import Text.Printf
import GHC.Exts

import Biobase.Primary
import Biobase.Secondary.Vienna
import Biobase.Vienna
import Biobase.Vienna.Default

import Tests.Comb



-- |

--testRNAfold :: String -> Int
testRNAfold inp' = struct `seq` bt `seq` (struct!(Z:.0:.n),bt) where
  (_,Z:._:.n) = bounds struct
  ener = fst turnerRNA2004
  inp = mkPrimary inp'
  tbls@(weak,block,comps,struct) = runST (rnafold ener inp)
  bt = btRNAfold ener inp tbls
{-# NOINLINE testRNAfold #-}

-- |

rnafold :: Vienna2004 -> Primary -> ST s
  ( Arr0 DIM2 Int
  , Arr0 DIM2 Int
  , Arr0 DIM2 Int
  , Arr0 DIM2 Int
  )
rnafold ener inp = do

  let !n = let (_,Z:.l) = bounds inp in l+1
  let inpv = VU.fromList $ toList inp
  let base   = base'   inp
  let baseLr = baseLr' inp
      {-# INLINE baseLr #-}
  let baselR = baselR' inp
      {-# INLINE baselR #-}
  let region = region' inpv
  let regionpl = regionpl' inpv
  let regionpr = regionpr' inpv
  let reglenpl = reglenpl' inp
  let reglenpr = reglenpr' inp
  let basepairing = basepairing' n inp
  let reglen = reglen' inp
      {-# INLINE reglen #-}
  -- this is a bit unfortunate, but otherwise we get type inference problems
  let hS :: S.Stream (ST s) Int -> ScalarM (ST s Int)
      hS = ScalarM . S.foldl' min (999999::Int)
      {-# INLINE hS #-}

  weak   <- fromAssocsM (Z:.0:.0) (Z:.n:.n) 999999 []
  block  <- fromAssocsM (Z:.0:.0) (Z:.n:.n) 999999 []
  comps  <- fromAssocsM (Z:.0:.0) (Z:.n:.n) 999999 []
  struct <- fromAssocsM (Z:.0:.0) (Z:.n:.n) 999999 []

  fillTables
    weak (
      multiOF  ener <<< baseLr -~~ (multiIF ener <<< block +~+ comps ... hS) ~~- baselR |||
      iloopOF  ener <<< baseLr -~~ (iloopIF ener <<< reglen ##~~ baseLr -~~ weak ~~- baselR ~~## reglen ... hS) ~~- baselR   |||
      iloop1NF  ener <<< base -~~ base -~~ base -~~ weak ~~- base ~~- base ~~@ reglen ~~- base ~~- base |||
      iloopN1F  ener <<< base -~~ base -~~ reglen @~~ base -~~ base -~~ weak ~~- base ~~- base ~~- base |||
      bulgeRF   ener <<< baseLr -~~ weak ~~- baselR ~~* reglen ~~- base  |||
      bulgeLF   ener <<< base -~~ reglen *~~ baselR -~~ weak ~~- baselR  |||
      tinyloopF ener <<< regionpr &~~ weak ~~& regionpl |||
      hairpinF  ener <<< baseLr -~~ region ~~- baselR ... h `with` basepairing )
    block ( -- exactly one loop for multibranch loops
      regionStemF ener <<< base -~~ block |||
      adjustStream n (justStemF ener <<< baseLr -~~ weak ~~- baselR)            ... h )
    comps (
      bcF <<< block +~+ comps  |||
      bsF <<< block +~+ reglen |||
      iD  <<< block            ... h )
    struct (
      ssF <<< reglen          |||
      iD  <<< weak            |||
      rSF <<< base -~~ struct |||
      cmF <<< weak +~+ struct ... h )

  weak'   <- freeze weak
  block'  <- freeze block
  comps'  <- freeze comps
  struct' <- freeze struct

  return
    ( weak'
    , block'
    , comps'
    , struct'
    )
{-# INLINE rnafold #-}

-- * backtracking
--
-- For now, we replicate the grammar as the optimizer is rather fragile

btRNAfold
  :: Vienna2004
  -> Primary
  -> (Arr0 DIM2 Int, Arr0 DIM2 Int, Arr0 DIM2 Int, Arr0 DIM2 Int)
  -> [String]
btRNAfold ener inp (weak,block,comps,struct) = structG (Z:.0:.n) where

  !n = let (_,Z:.l) = bounds inp in l+1
  inpv = VU.fromList $ toList inp
  base   = base'   inp
  baseLr = baseLr' inp
  {-# INLINE baseLr #-}
  baselR = baselR' inp
  {-# INLINE baselR #-}
  region = region' inpv
  regionpl = regionpl' inpv
  regionpr = regionpr' inpv
  reglenpl = reglenpl' inp
  reglenpr = reglenpr' inp
  basepairing = basepairing' n inp
  reglen = reglen' inp
  {-# INLINE reglen #-}

  --

  weak' :: DIM2 -> Scalar (Int, [String])
  weak' ij = Scalar (weak!ij, weakG ij)

  block' :: DIM2 -> Scalar (Int, [String])
  block' ij = Scalar (block!ij, blockG ij)

  comps' :: DIM2 -> Scalar (Int, [String])
  comps' ij = Scalar (comps!ij, compsG ij)

  struct' :: DIM2 -> Scalar (Int, [String])
  struct' ij = Scalar (struct!ij, structG ij)

  --

  weakG :: DIM2 -> [String]
  weakG = (
            multiBT ener    <<< baseLr -~~ block' +~+ comps' ~~- baselR |||
            iloopBT ener    <<< baseLr -~~ reglen ##~~ baseLr -~~ weak' ~~- baselR ~~## reglen ~~- baselR |||
            iloop1NBT ener  <<< base -~~ base -~~ base -~~ weak' ~~- base ~~- base ~~@ reglen ~~- base ~~- base |||
            iloopN1BT ener  <<< base -~~ base -~~ reglen @~~ base -~~ base -~~ weak' ~~- base ~~- base ~~- base |||
            bulgeRBT ener   <<< baseLr -~~ weak' ~~- baselR ~~* reglen ~~- base  |||
            bulgeLBT ener   <<< base -~~ reglen *~~ baselR -~~ weak' ~~- baselR  |||
            tinyloopBT ener <<< regionpr &~~ weak' ~~& regionpl |||
            hairpinBT  ener <<< baseLr -~~ region ~~- baselR ..@ (hBT weak)
          )

  blockG :: DIM2 -> [String]
  blockG = (
             regionStemBT ener <<< base -~~ block' |||
             adjustStreamBT n (justStemBT ener <<< baseLr -~~ weak' ~~- baselR) ..@ (hBT block)
           )

  compsG :: DIM2 -> [String]
  compsG = ( bcBT <<< block' +~+ comps' |||
             bsBT <<< block' +~+ reglen |||
             iDBT <<< block'            ..@ (hBT comps)
           )

  structG :: DIM2 -> [String]
  structG = ( ssBT <<< reglen            |||
              iDBT <<< weak'             |||
              rSBT <<< base -~~ struct'  |||
              cmBT <<< weak' +~+ struct' ..@ (hBT struct)
            )

  multiBT ener l (b,bS) (c,cS) r = let e = multiOF ener l (multiIF ener b c) r
                                   in (e, ["("++x++y++")" | x<-bS, y<-cS])
  iloopBT ener lo llen li (w,wS) ri rlen ro = let e = iloopOF ener lo (iloopIF ener llen li w ri rlen) ro
                                              in (e, L.map (\s -> "("++replicate llen '.'++"("++s++")"++replicate rlen '.'++")") wS)
  iloop1NBT ener l1 l2 l3 (w,wS) r1 r2 rlen r3 r4 = let e = iloop1NF ener l1 l2 l3 w r1 r2 rlen r3 r4
                                                    in (e, L.map (\s -> "(.("++s++")."++replicate rlen '.'++".)") wS)
  iloopN1BT ener l1 l2 llen l3 l4 (w,wS) r1 r2 r3 = let e = iloopN1F ener l1 l2 llen l3 l4 w r1 r2 r3
                                                    in (e, L.map (\s -> "(."++replicate llen '.'++".("++s++".") wS)
  bulgeRBT ener ll (w,wS) rr rlen r = let e = bulgeRF ener ll w rr rlen r
                                      in (e, L.map (\s -> "("++s++"."++replicate rlen '.'++")") wS)
  bulgeLBT ener l llen ll (w,wS) rr = let e = bulgeLF ener l llen ll w rr
                                      in (e, L.map (\s -> "("++replicate llen '.'++"."++s++")") wS)
  hairpinBT ener llp reg rpr = let e = hairpinF ener llp reg rpr
                               in (e, if e<10000 then ["(" ++ replicate (VU.length reg) '.' ++ ")"] else [])
  tinyloopBT ener ls (w,sW) rs = let e = tinyloopF ener ls w rs
                                 in (e, L.map (\s -> "("++replicate (VU.length ls-2) '.'++s++replicate (VU.length rs-2) '.'++")") sW)

  regionStemBT ener nc (w,sW) = let e = regionStemF ener nc w
                                in (e, L.map (\s -> "." ++ s) sW)
  justStemBT ener llp (w,sW) rpr = let e = justStemF ener llp w rpr
                                   in (e, sW)

  bcBT (b,bW) (c,cW) = let e = b+c
                       in (e,[ x++y | x<-bW, y<-cW ])
  bsBT (b,bW) reg = (b, L.map (++ replicate reg '.') bW)
  iDBT = id

  ssBT len = (ssF len, [replicate len '.'])
  rSBT n (w,wS) = let e = rSF n w
                  in (e, if e<0 then map ("."++) wS else [])
  cmBT (w,wS) (s,sS) = let e = cmF w s
                       in (e, [x++y | x<-wS, y<-sS])

  hBT tbl ij = L.concatMap snd . L.filter ((tbl!ij==).fst) . P.toList



-- * different energy functions (very simplified signature)

-- |

hairpinF :: Vienna2004 -> (Nuc,Nuc) -> (VU.Vector Nuc) -> (Nuc,Nuc) -> Int
hairpinF Vienna2004{..} (l,lp) reg (rp,r)
  -- TODO use sliceEq for tabulated hairpins
  {-
  | len <= 6, Just v <- find tabulated hairpin
  -}
  | len <  3  = 999999
  | len == 3  = hairpinL!(Z:.len) + tAU
  | len > 31  = hairpinL!(Z:.30)  + hairpinMM!(Z:.p:.lp:.rp) + llp
  | otherwise = {-# CORE "hairpinF" #-} hairpinL!(Z:.len) + hairpinMM!(Z:.p:.lp:.rp)
  where p   = mkViennaPair (l,r)
        len = VU.length reg
        tAU = if p/=vpCG && p/=vpGC then termAU else 0
        llp = floor $ 108.856 * log (fromIntegral len / 30)
{-# INLINE hairpinF #-}

-- | This captures a set of loops with 1-4 nucleotides added to the left and/or
-- right. This captures several kinds of tabulated loops.

tinyloopF :: Vienna2004 -> VU.Vector Nuc -> Int -> VU.Vector Nuc -> Int
tinyloopF Vienna2004{..} ls w rs
  | dl==0 || dr==0 = error "bug in tinyloop"
  -- normal stack
  | dl==1 && dr==1 = w+stack!(Z:.op:.ip)
  -- one intervening unpaired nucleotide doesn't break the stack
  | dl==1 && dr==2 = w+stack!(Z:.op:.ip)+bulgeL!(Z:.1)
  | dl==2 && dr==1 = w+stack!(Z:.op:.ip)+bulgeL!(Z:.1)
  -- 1x1 symmetric interior loop
  | dl==2 && dr==2 = w+iloop1x1!(Z:.op:.ip:.bI:.bJ)
  -- 1x2 interior loop
  | dl==2 && dr==3 = w+iloop2x1!(Z:.op:.ip:.bI:.bL:.bJ)
  -- 2x1 interior loop
  | dl==3 && dr==2 = w+iloop2x1!(Z:.op:.ip:.bJ:.bI:.bK)
  -- 2x2 interior loop
  | dl==3 && dr==3 = w+iloop2x2!(Z:.op:.ip:.bI:.bK:.bL:.bJ)
  -- 2x3 interior loops with specialized mismatches
  |  dl==3 && dr==4
  || dl==4 && dr==3 = w+iloop2x3MM!(Z:.op:.bI:.bJ) + iloop2x3MM!(Z:.ip:.bL:.bK) + iloopL!(Z:.5) + ninio
  | otherwise      = 999999 -- overlaps with big interior loops
  where
    op = mkViennaPair (VU.head ls, VU.last rs)
    ip = mkViennaPair (VU.head rs, VU.last ls)
    bI = VU.head $ VU.drop 1 ls
    bJ = VU.last $ VU.init   ls
    bK = VU.head $ VU.drop 1 rs
    bL = VU.last $ VU.init   rs
    dl = VU.length ls -1
    dr = VU.length rs -1
{-# INLINE tinyloopF #-}

-- |

iD = id
{-# INLINE iD #-}

-- |

regionStemF :: Vienna2004 -> Nuc -> Int -> Int
regionStemF Vienna2004{..} _ w = w + multiNuc
{-# INLINE regionStemF #-}

-- |

justStemF :: Vienna2004 -> (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> Int
justStemF Vienna2004{..} (l,lp) w (rp,r) = w + multiMM!(Z:.p:.lp:.rp)
  where p = mkViennaPair (l,r)
{-# INLINE justStemF #-}

-- |

bcF :: Int -> Int -> Int
bcF b c = b + c
{-# INLINE bcF #-}

-- |

bsF :: Int -> Int -> Int
bsF b reg = b
{-# INLINE bsF #-}

-- |

ssF :: Int -> Int
ssF reg = 0
{-# INLINE ssF #-}

-- |

rSF :: Nuc -> Int -> Int
rSF nuc w = w
{-# INLINE rSF #-}

-- |

cmF :: Int -> Int -> Int
cmF w s = w+s
{-# INLINE cmF #-}

-- |

multiIF :: Vienna2004 -> Int -> Int -> Int
multiIF Vienna2004{..} b c = b+c
{-# INLINE multiIF #-}

-- |

multiOF :: Vienna2004 -> (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> Int
multiOF Vienna2004{..} (l,lp) multiif (rp,r) = multiif + multiMM!(Z:.p:.lp:.rp) + multiHelix + multiOffset + terminalAU termAU p
  where p = mkViennaPair (l,r)
{-# INLINE multiOF #-}

-- |
--
-- NOTE On a length-100/1000 sequence, going from safe functions to unsafe ones
-- means going from 53ms / 9.3s to 24ms / 4s!

iloopT :: Vienna2004 -> VU.Vector Nuc -> Int -> VU.Vector Nuc -> Int
iloopT Vienna2004{..} ls w rs = w + iloopMM!(Z:.p:.bR:.bL) + iloopL!(Z:.len) + owninio where
  p = mkViennaPair (VU.unsafeHead rs, VU.unsafeLast ls)
  bL = VU.unsafeLast $ VU.unsafeInit   ls
  bR = VU.unsafeHead $ VU.unsafeDrop 1 rs
  len = VU.length ls + VU.length rs -2 -- we are peeking, hence -2
  owninio = min maxNinio (ninio * (abs $ VU.length ls - VU.length rs))
{-# INLINE iloopT #-}

iloopIF :: Vienna2004 -> Int -> (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> Int -> Int
iloopIF Vienna2004{..} lenL (l,lp) w (rp,r) lenR = {-# CORE "iloopIF" #-} w + iloopMM!(Z:.p:.r:.l) + iloopL!(Z:.len) + owninio where
  p = mkViennaPair (rp,lp)
  len = lenL+lenR+2
  owninio = min maxNinio (ninio * (abs $ lenL - lenR))
{-# INLINE iloopIF #-}

iloopTF :: Vienna2004 -> (Int,Nuc,Nuc) -> Int -> (Nuc,Nuc,Int) -> Int
iloopTF Vienna2004{..} (lenL,l,lp) w (rp,r,lenR) = w + iloopMM!(Z:.p:.r:.l) + iloopL!(Z:.len) + owninio where
  p = mkViennaPair (rp,lp)
  len = lenL+lenR+2
  owninio = min maxNinio (ninio * (abs $ lenL - lenR))
{-# INLINE iloopTF #-}

-- |

iloopOF :: Vienna2004 -> (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> Int
iloopOF Vienna2004{..} (l,lp) iloopif (rp,r) = {-# CORE "iloopOF" #-} iloopif + iloopMM!(Z:.op:.lp:.rp)
  where op = mkViennaPair (l,r)
{-# INLINE iloopOF #-}

-- | Bulges are complicated: (l,r) form an enclosing nucleotide pair. len is
-- the length of the loop with 1-29 nucleotides. 'c' is another unpaired
-- nucleotide bringing the total to 2-30. (rp,cp) is an (inverted) pair, which
-- closes the w(eak) subword (and is at this point already closed, so we peek!
--
-- @(....[[...]])@

bulgeLF :: Vienna2004 -> Nuc -> Int -> (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> Int
bulgeLF Vienna2004{..} l len (c,cp) w (rp,r) = w + tAUlr + lenE + tAUrpcp where
  tAUlr = terminalAU termAU lr
  tAUrpcp = terminalAU termAU rpcp
  lr = mkViennaPair (l,r)
  rpcp = mkViennaPair (rp,cp)
  lenE = bulgeL!(Z:.len+1)
{-# INLINE bulgeLF #-}

-- |
--
-- @(.[[...]]....)@

bulgeRF :: Vienna2004 -> (Nuc,Nuc) -> Int -> (Nuc,Nuc) -> Int -> Nuc -> Int
bulgeRF Vienna2004{..} (l,lp) w (cp,c) len r = w + tAUlr + lenE + tAUcplp where
  tAUlr = terminalAU termAU lr
  tAUcplp = terminalAU termAU cplp
  lr = mkViennaPair (l,r)
  cplp = mkViennaPair (cp,lp)
  lenE = bulgeL!(Z:.len+1)
{-# INLINE bulgeRF #-}

-- | A weak region is enclosed by an inner pair (cl,cr) with mismatch and an
-- outer pair (l,r) with mismatch. The smallest length on the left is 3, as all
-- 1x2 interior loops are tabulated.
--
-- @(....[[...]].)@
--
-- TODO split into inner+outer part for more speed (also showing that doing so
-- is easy!)

iloopN1F :: Vienna2004 -> Nuc -> Nuc -> Int -> Nuc -> Nuc -> Int -> Nuc -> Nuc -> Nuc -> Int
iloopN1F Vienna2004{..} l lm len clm cl w cr rm r = w + outerMM + lenE + innerMM + owninio where
  poLR = mkViennaPair (l,r)
  piRL = mkViennaPair (cr,cl)
  outerMM = iloopMM!(Z:.poLR:.lm:.rm)
  innerMM = iloopMM!(Z:.piRL:.rm:.clm)
  lenE = iloopL!(Z:.(len + 2 + 1)) -- at least 3 unpaired on the left (2 and len>=1) and one on the right
  owninio = min maxNinio (ninio * (len + 2 - 1)) -- difference in length

{-# INLINE iloopN1F #-}

-- | Mirror image to 'iloopN1F'

iloop1NF :: Vienna2004 -> Nuc -> Nuc -> Nuc -> Int -> Nuc -> Nuc -> Int -> Nuc -> Nuc -> Int
iloop1NF Vienna2004{..} l lm cl w cr crm len rm r = w + outerMM + lenE + innerMM + owninio where
  poLR = mkViennaPair (l,r)
  piRL = mkViennaPair (cr,cl)
  outerMM = iloopMM!(Z:.poLR:.lm:.rm)
  innerMM = iloopMM!(Z:.piRL:.crm:.lm)
  lenE = iloopL!(Z:.(len + 2 + 1))
  owninio = min maxNinio (ninio * (len + 2 - 1))
{-# INLINE iloop1NF #-}

-- |

h :: Monad m => S.Stream m Int -> m Int
h = S.foldl' min (999999::Int)
{-# INLINE h #-}

-- |

terminalAU termAU p = if p/=vpCG && p/=vpGC then termAU else 0
{-# INLINE terminalAU #-}



-- * Functions that will be part of a bioinformatics DP library

-- ** Specialized combinators for interior loops and bulges.
--
-- The first one allows only 2-30 free nucleotides. The second one as well, but
-- is further restricted by what the first one already consumed. So if the
-- first consumed 5 nucleotides already, the second one consumes between 2-25
-- nucleotides.
--
-- Unfortunately, as the number of special cases grows, one has to start
-- resorting to writing them using 'Box' itself. But for this, we use one of
-- the existing 'make' functions.

infixl 9 *~~, ~~*, @~~, ~~@, &~~, ~~&

-- |

(&~~) = makeLeftCombinator 1 4
{-# INLINE (&~~) #-}

(~~&) = makeRightCombinator 1 4
{-# INLINE (~~&) #-}

-- | In xs *~~ ys, xs is a subword with size 1 to 29.

(*~~) = makeLeftCombinator 1 29
{-# INLINE (*~~) #-}

-- | In xs ~~* ys, ys is a subword with size 1 to 29.

(~~*) = makeRightCombinator 1 29
{-# INLINE (~~*) #-}

-- |

(@~~) = makeLeftCombinator 1 28
{-# INLINE (@~~) #-}

-- |

(~~@) = makeRightCombinator 1 28
{-# INLINE (~~@) #-}

-- **

-- "block" are a bit complicated, since we need to peek outside the current
-- boundaries to get the outer nucleotides. We do this by /actually changing
-- the boundaries/ but only if they remain valid. This change is ok since the
-- combinators remove one base left and right again.
adjustIdx :: Int -> (DIM2 -> ST s Int) -> DIM2 -> ST s Int
adjustIdx !n sgen (Z:.i:.j) = if i>0 && j<n then sgen (Z:.i-1:.j+1) else return 999999
{-# INLINE adjustIdx #-}

adjustStream :: Int -> (DIM2 -> S.Stream (ST s) Int) -> DIM2 -> S.Stream (ST s) Int
adjustStream !n sgen (Z:.i:.j)
  | i>0 && j<n = sgen (Z:.i-1:.j+1)
  | otherwise  = S.empty
{-# INLINE adjustStream #-}

adjustStreamBT :: Int -> (DIM2 -> P.Stream elm) -> DIM2 -> P.Stream elm
adjustStreamBT !n sgen (Z:.i:.j)
  | i>0 && j<n = sgen (Z:.i-1:.j+1)
  | otherwise  = P.empty
{-# INLINE adjustStreamBT #-}

infixl 6 .!.
(.!.) stream (h,n) (Z:.i:.j)
  | i>0 && j<n = h $ stream (Z:.i-1:.j+1)
  | otherwise  = h $ S.empty
{-# INLINE (.!.) #-}


-- |

infixl 5 `with`
with xs cond ij = if cond ij then xs ij else return 999999
{-# INLINE with #-}

-- |

fillTables
  :: PrimMonad m
  => MArr0 (PrimState m) DIM2 Int -> (DIM2 -> m Int)
  -> MArr0 (PrimState m) DIM2 Int -> (DIM2 -> m Int)
  -> MArr0 (PrimState m) DIM2 Int -> (DIM2 -> m Int)
  -> MArr0 (PrimState m) DIM2 Int -> (DIM2 -> m Int)
  -> m ()
fillTables aT aF bT bF cT cF dT dF = do
  let (_,Z:.n:._) = boundsM aT
  forM_ [n,n-1 .. 0] $ \i -> forM_ [i..n] $ \j -> do
    let ij = Z:.i:.j
    aF ij >>= writeM aT ij
    bF ij >>= writeM bT ij
    cF ij >>= writeM cT ij
    dF ij >>= writeM dT ij
{-# INLINE fillTables #-}

-- |

base' :: Primary -> DIM2 -> (Scalar Nuc)
base' inp (Z:.i:.j) = Scalar $ index inp (Z:.i)
{-# INLINE base' #-}

-- | Nucleotide, second one to the right.

baseLr' :: Primary -> DIM2 -> (Scalar (Nuc,Nuc))
baseLr' inp (Z:.i:.j) = Scalar $ (index inp (Z:.i), index inp (Z:.i+1))
{-# INLINE baseLr' #-}

-- |

baselR' :: Primary -> DIM2 -> (Scalar (Nuc,Nuc))
baselR' inp (Z:.i:.j) = Scalar $ (index inp (Z:.i-1), index inp (Z:.i))
{-# INLINE baselR' #-}

-- |

region' :: VU.Vector Nuc -> DIM2 -> (Scalar (VU.Vector Nuc))
region' inp (Z:.i:.j) = Scalar $ VU.unsafeSlice i (j-i) inp
{-# INLINE region' #-}

-- | Vector of nucleotides peeking one nucleotide to the left.

regionpl' :: VU.Vector Nuc -> DIM2 -> (Scalar (VU.Vector Nuc))
regionpl' inp (Z:.i:.j) = Scalar $ VU.unsafeSlice (i-1) (j-i+1) inp
{-# INLINE regionpl' #-}

-- | Vector of nucleotides peeaking one nucleotide to the right.

regionpr' :: VU.Vector Nuc -> DIM2 -> (Scalar (VU.Vector Nuc))
regionpr' inp (Z:.i:.j) = Scalar $ VU.unsafeSlice i (j-i+1) inp
{-# INLINE regionpr' #-}

-- |

basepairing' n inp (Z:.i:.j) = tf
  where p  = mkViennaPair (inp!(Z:.i), inp!(Z:.j-1))
        tf = i>=0 && j>0 && i<n && j-1<n && p /= vpNS
{-# INLINE basepairing' #-}

-- |

reglen' :: Primary -> DIM2 -> Scalar Int
reglen' inp (Z:.i:.j) = Scalar $ j-i
{-# INLINE reglen' #-}

-- |

reglenpl' :: Primary -> DIM2 -> Scalar (Nuc,Nuc,Int)
reglenpl' inp (Z:.i:.j) = Scalar (index inp (Z:.i-1),index inp (Z:.i),j-i)
{-# INLINE reglenpl' #-}

reglenpr' :: Primary -> DIM2 -> Scalar (Int,Nuc,Nuc)
reglenpr' inp (Z:.i:.j) = Scalar (j-i,index inp (Z:.j-1), index inp (Z:.j))
{-# INLINE reglenpr' #-}
