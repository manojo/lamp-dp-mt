{-# LANGUAGE RecordWildCards #-}

module Tests.Vienna where

import Control.Monad.ST
import Control.Monad
import Control.Monad.Primitive
import Data.Array.Repa.Index
import Data.Array.Repa.Shape
import qualified Data.Vector.Unboxed as VU
import qualified Data.Vector.Fusion.Stream.Monadic as S

import Data.PrimitiveArray as PA
import Data.PrimitiveArray.Unboxed.Zero as PA
import ADP.Fusion.Monadic
import ADP.Fusion.Monadic.Internal
import Biobase.Primary
import Biobase.Secondary.Vienna
import Biobase.Vienna
import Biobase.Vienna.ImportPar
import Biobase.Vienna.Import
import Biobase.Vienna.Default

import Debug.Trace



test :: IO ()
test = do
  let Vienna2004{..} = fst turnerRNA2004
  print $ bounds stack
  print $ toList stack
  return ()
