
module ADP.Fusion.Monadic where

import Data.Array.Repa.Index
import qualified Data.Vector.Fusion.Stream.Monadic as S

import ADP.Fusion.Monadic.Internal

import Debug.Trace



-- * Apply functions to arguments, combine different terms, and apply a
-- function to select the optimal result from many candidates.

-- |

infixl 8 #<<
(#<<) f t ij = S.mapM (\(_,_,c) -> apply f c) $ streamGen t ij
{-# INLINE (#<<) #-}

infixl 8 <<<
(<<<) f t ij = S.map (\(_,_,c) -> apply f c) $ streamGen t ij
{-# INLINE (<<<) #-}

-- |

infixl 7 |||
(|||) xs ys ij = xs ij S.++ ys ij
{-# INLINE [1] (|||) #-}

-- |

infixl 6 ...
(...) stream h ij = h $ stream ij
{-# INLINE [2] (...) #-}

-- | Specialized version of choice function application, with a choice function
-- that needs to know the subword index, it is working on.

infixl 6 ..@
(..@) stream h ij = h ij $ stream ij
{-# INLINE (..@) #-}



-- * Combinator descriptions assume that @xs ~~~ ys@ with @xs[i,k]@ and
-- @ys[k,j]@

-- | Yields all combinations of @xs[i,k] ys[k,j]@ with @i <= k <= j@.

infixl 9 ~~~
(~~~) xs ys = Box xs mk step ys where
  {-# INLINE mk #-}
  mk (z:.k:.j,a,b) = return (z:.k:.k:.j,a,b)
  {-# INLINE step #-}
  step (z:.k:.l:.j,a,b)
    | l<=j      = return $ S.Yield (z:.k:.l:.j,a,b) (z:.k:.(l+1):.j,a,b)
    | otherwise = return $ S.Done
{-# INLINE (~~~) #-}

-- | @xs -~~ ys@ yields xs[i,i+1] in step 1, then is done.

infixl 9 -~~
(-~~) xs ys = Box xs mk step ys where
  {-# INLINE mk #-}
  mk (z:.k:.j,vidx,vstack) = return $ (z:.k:.k+1:.j,vidx,vstack)
  {-# INLINE step #-}
  step (z:.k:.l:.j,vidx,vstack)
    | l<=j      = return $ S.Yield (z:.k:.l:.j,vidx,vstack) (z:.k:.j+1:.j,vidx,vstack)
    | otherwise = return $ S.Done
{-# INLINE (-~~) #-}

-- | @xs ~~- ys@ yields ys[j-1,j] in step 1, then is done.

infixl 9 ~~-
(~~-) xs ys = Box xs mk step ys where
  {-# INLINE mk #-}
  --mk (z:.k:.j,vidx,vstack) = return $ (z:.k:.(max k $ j-1):.j,vidx,vstack)
  mk (z:.k:.j,vidx,vstack) = return $ (z:.k:.k:.j,vidx,vstack)
  {-# INLINE step #-}
  step (z:.k:.l:.j,vidx,vstack)
    | l+1<j     = return $ S.Skip  (z:.k:.j-1:.j,vidx,vstack)
    | l+1==j    = return $ S.Yield (z:.k:.l:.j,vidx,vstack) (z:.k:.j+1:.j,vidx,vstack)
    | otherwise = return $ S.Done
{-# INLINE (~~-) #-}

-- | All combinations of @xs[i,k] ys[k,j]@ with @i < k < j@.

infixl 9 +~+
(+~+) xs ys = Box xs mk step ys where
  {-# INLINE mk #-}
  mk (z:.k:.j,vidx,vstack) = return $ (z:.k:.k+1:.j,vidx,vstack)
  {-# INLINE step #-}
  step (z:.k:.l:.j,vidx,vstack)
    | l+1<=j    = return $ S.Yield (z:.k:.l:.j,vidx,vstack) (z:.k:.l+1:.j,vidx,vstack)
    | otherwise = return $ S.Done
{-# INLINE (+~+) #-}



-- * Specialized combinator builders for required minimal / maximal number of
-- characters.
--
-- NOTE All these combinators assume that you do not put in negative values for
-- minC/maxC.
--
-- TODO given @xs ~~~ ys@ we need combinators with min/max steps property at
-- the xs and at the ys side separately.
--
-- TODO then we need a "deep 1" combinator for the ys side @in ws ~~~ xs ~~~
-- ys@ that can look one down and to min/max constrained on the number of steps
-- already taken.
--
-- TODO later on, "deep 2" and more could be interesting.

-- | A left combinator with minimal and maximal distance. In @xs ~~~ ys@, this
-- combinator will only permit subwords on xs that are between minC and maxC.
-- That is @xs :: (i,j) -> ?@ with @j-i>=minC and j-i<=maxC@.

makeLeftCombinator minC maxC = comb where
  {-# INLINE comb #-}
  comb xs ys = Box xs mk step ys where
    {-# INLINE mk #-}
    mk (z:.k:.j,a,b) = return (z:.k:.k+minC:.j,a,b)
    {-# INLINE step #-}
    step (z:.k:.l:.j,a,b)
      | l<=j && l<=k+maxC = return $ S.Yield (z:.k:.l:.j,a,b) (z:.k:.l+1:.j,a,b)
      | otherwise = return $ S.Done
{-# INLINE makeLeftCombinator #-}

-- | A right combinator with minimal and maximal distance. In @xs ~~~ ys@, this
-- combinator restricts subwords in ys.

makeRightCombinator minC maxC = comb where
  {-# INLINE comb #-}
  comb xs ys = Box xs mk step ys where
    {-# INLINE mk #-}
--    mk (z:.k:.j,a,b) = let l = max k (j-maxC) in {- traceShow ("mk",minC,maxC,k,l,j) $ -} return (z:.k:.l:.j,a,b)
    mk (z:.k:.j,a,b) = let l = k in {- traceShow ("mk",minC,maxC,k,l,j) $ -} return (z:.k:.l:.j,a,b)
    {-# INLINE step #-}
    step (z:.k:.l:.j,a,b)
      | l+maxC<j  = return $ S.Skip (z:.k:.j-maxC:.j,a,b)
      | l<=j-minC = {- traceShow ("step",k,l,j) $ -} return $ S.Yield (z:.k:.l:.j,a,b) (z:.k:.l+1:.j,a,b)
      | otherwise = return $ S.Done
{-# INLINE makeRightCombinator #-}

-- | This version behaves like 'makeRightCombinator' but, in addition,
-- minC/maxC is influenced by a combinator one more to the left. This allows
-- writing combinators that are dependent on each other.

makeRightOneCombinator minC maxC = comb where
  {-# INLINE comb #-}
  comb xs ys = Box xs mk step ys where
    {-# INLINE mk #-}
    mk (z:.k:.j,a,b) = let (_:.i) = z
                           cnsmd = k-i -- consumed part
                           l = max k (j-maxC-cnsmd)
                       in return (z:.k:.l:.j,a,b)
    {-# INLINE step #-}
    step (z:.k:.l:.j,a,b)
      | l<=j-(max 0 $ minC - cnsmd)
      = return $ S.Yield (z:.k:.l:.j,a,b) (z:.k:.l+1:.j,a,b)
      | otherwise = return $ S.Done
      where cnsmd  = k-i
            (_:.i) = z
{-# INLINE makeRightOneCombinator #-}

-- | This one behaves like 'makeRightOneCombinator' but will always observe the
-- 'minC' requirement.

makeRightOneMinCombinator minC maxC = comb where
  {-# INLINE comb #-}
  comb xs ys = Box xs mk step ys where
    {-# INLINE mk #-}
    mk (z:.k:.j,a,b) = let (_:.i) = z
                           cnsmd = k-i -- consumed part
                           l = max k (j-maxC-cnsmd)
                       in return (z:.k:.l:.j,a,b)
    {-# INLINE step #-}
    step (z:.k:.l:.j,a,b)
      | l<=j-minC = return $ S.Yield (z:.k:.l:.j,a,b) (z:.k:.l+1:.j,a,b)
      | otherwise = return $ S.Done
{-# INLINE makeRightOneMinCombinator #-}

