{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE NoMonomorphismRestriction #-}

-- | QuickCheck properties for a number of ADPfusion combinators.

module ADP.Fusion.QuickCheck where

import Data.Array.Repa.Index
import Data.Vector.Fusion.Stream.Size
import Data.Vector.Fusion.Util
import qualified Data.Vector.Fusion.Stream as S
import qualified Data.Vector.Unboxed as VU
import Test.QuickCheck
import Test.QuickCheck.All
import Data.List

import qualified ADP.Legacy as L
import qualified ADP.Fusion as F
import qualified ADP.Fusion.Monadic as M
import qualified ADP.Fusion.Monadic.Internal as F



options = stdArgs {maxSuccess = 1000}

customCheck = quickCheckWithResult options

allProps = $forAllProperties customCheck



lAchar (i,j) = [j | i+1 == j]

-- |
--
-- NOTE we have to add 1 to the i-index. Legacy ADP reads chars from an input
-- array starting at "1", while ADPfusion starts arrays at "0".

fAchar :: DIM2 -> (F.Scalar Int)
fAchar (Z:.i:.j) = F.Scalar $ (i+1)

lRegion = L.astring

fRegion :: DIM2 -> (F.Scalar (Int,Int))
fRegion (Z:.i:.j) = F.Scalar $ (i,j)

-- ** single left

lLeft = (,) L.<<< lAchar L.-~~ lRegion L.... id

fLeft (i,j) = S.toList $ (,) F.<<< fAchar F.-~~ fRegion F.... id $ Z:.i:.j

prop_Left (Small i, Small j) = lLeft (i,j) == fLeft (i,j)


-- ** single right

lRight = (,) L.<<< lRegion L.~~- lAchar L.... id

fRight (i,j) = S.toList $ (,) F.<<< fRegion F.~~- fAchar F.... id $ Z:.i:.j

prop_Right (Small i, Small j) = lRight (i,j) == fRight (i,j)


-- ** hairpin tests

lHairpin = (,,) L.<<< lAchar L.-~~ lRegion L.~~- lAchar L.... id

fHairpin (i,j) = S.toList $ (,,) F.<<< fAchar F.-~~ fRegion F.~~- fAchar F.... id $ (Z:.i:.j)

prop_Hairpin (Small i,Small j) = lHairpin (i,j) == fHairpin (i,j)

-- ** complex

lComplex = (,,,) L.<<< lAchar L.-~~ lRegion L.~~~ lRegion L.~~- lAchar L.... id

fComplex (i,j) = S.toList $ (,,,) F.<<< fAchar F.-~~ fRegion F.~~~ fRegion F.~~- fAchar F.... id $ (Z:.i:.j)

prop_Complex (Small i,Small j) = lComplex (i,j) == fComplex (i,j)

-- ** 2 regions

lRegion2 = (,) L.<<< lRegion L.~~~ lRegion L.... id

fRegion2 (i,j) = S.toList $ (,) F.<<< fRegion F.~~~ fRegion F.... id $ (Z:.i:.j)

prop_Region2 (Small i,Small j) = lRegion2 (i,j) == fRegion2 (i,j)

-- ** 3 regions

lRegion3 = sort . ((,,) L.<<< lRegion L.~~~ lRegion L.~~~ lRegion L.... id)

fRegion3 (i,j) = sort . S.toList $ (,,) F.<<< fRegion F.~~~ fRegion F.~~~ fRegion F.... id $ (Z:.i:.j)

prop_Region3 (Small i,Small j) = lRegion3 (i,j) == fRegion3 (i,j)

-- ** 2 regions with specialized combinator

lRegion2s = (,) L.<<< lRegion L.+~+ lRegion L.... id

fRegion2s (i,j) = S.toList $ (,) F.<<< fRegion F.+~+ fRegion F.... id $ (Z:.i:.j)

prop_Region2s (Small i,Small j) = lRegion2s (i,j) == fRegion2s (i,j)

-- ** 3 regions with specialized combinator
--
-- NOTE this property fails, the rhs of +~+ (lregion ~~~ lregion) only has to
-- be non-empty, while the legacy ADP version requires the in xs +~+ ys ~~~ zs
-- that (ys) is nonempty.

lRegion3s = sort . ((,,) L.<<< lRegion L.+~+ lRegion L.~~~ lRegion L.... id)

fRegion3s (i,j) = sort . S.toList $ (,,) F.<<< fRegion F.+~+ fRegion F.~~~ fRegion F.... id $ (Z:.i:.j)

fail_prop_Region3s (Small i,Small j) = lRegion3s (i,j) == fRegion3s (i,j)

-- ** 3 regions with specialized combinators

lRegion3ss = sort . ((,,) L.<<< lRegion L.+~+ lRegion L.+~+ lRegion L.... id)

fRegion3ss (i,j) = sort . S.toList $ (,,) F.<<< fRegion F.+~+ fRegion F.+~+ fRegion F.... id $ (Z:.i:.j)

prop_Region3ss (Small i,Small j) = lRegion3ss (i,j) == fRegion3ss (i,j)

-- ** many ~~- combinators

lRightFixed3 = sort . ((,,,) L.<<< lRegion L.~~- lRegion L.~~- lRegion L.~~- lRegion L.... id)

fRightFixed3 (i,j) = sort . S.toList $ (,,,) F.<<< fRegion F.~~- fRegion F.~~- fRegion F.~~- fRegion F.... id $ (Z:.i:.j)


-- * quickcheck stuff

newtype Small = Small Int
  deriving (Show)

instance Arbitrary Small where
  arbitrary = Small `fmap` choose (0,50)
  shrink (Small x)
    | x>0       = [Small $ x-1]
    | otherwise = []

small x = x>=0 && x <=50

