
ADPfusion
(c) 2012, Christian Hoener zu Siederdissen
University of Vienna, Vienna, Austria
choener@tbi.univie.ac.at
LICENSE: BSD3



Introduction
============

ADPfusion is a framework for efficient combinators for dynamic programming. The
long-term goal is to be able to write high-level dynamic programming algorithms
in a very high-level style similar to ADP.

This is a preview-version that comes with simplified versions of two algorithms
(Nussinov78 and RNAfold). We use these two programs to test how far away in
terms of runtime we are from C.

"Simplified" means that we perform the same computations as in RNAfold, but not
in all detail. ViennaRNA RNAfold has many options like "dangles 0/1/2" that
have (almost) no impact on compution time but require some thought to get
right. Here we only want to deal with high-performance code.

The "C" folder contains a much simplified version of Nussinov78 written in C.
This version only fills the DP matrix, i.e. the forward step.

All the Haskell versions are under Tests/.

Because compilation takes minutes for Tests/STrnafold.hs (Thanks to type
families), the RNAfold example is disabled by default. It can be enabled by:
cabal-dev install --flags="rnafold"

Please note that "backtracking" is currently an afterthought, both backtracking
and all the small helper functions need to be cleaned up (e.g. helper functions
go into their own module).



Installation
============

Please use GHC-7.2.2, if possible. GHC-7.4 currently seems to have problems
optimizing vector-dependent code:
http://hackage.haskell.org/trac/ghc/ticket/5539
(and others?)

If GHC-7.2.2, LLVM and cabal-install are available, you should be all set. I
recommend using cabal-dev as it provides a very nice sandbox (replace cabal-dev
with cabal otherwise).

tar xzf ADPfusion-w.x.y.z.tar.gz
cabal update
cd ADPfusion
cabal-dev install
zcat testinput.gz | ./cabal-dev/bin/Nussinov



Notes
=====

If you have problems, find bugs, or want to use this library to write your own
DP algorithms, please send me a mail. I'm very interested in hearing what is
missing.

One of the things I'll be integrating is an extension to higher dimensions
(more than two).

Right now, I am not quite happy with the construction and destruction of the
"Box" representations. These will change soon. In addition, an analysis of the
actual combinators should remove the need for nested applications of objective
functions in many cases.
