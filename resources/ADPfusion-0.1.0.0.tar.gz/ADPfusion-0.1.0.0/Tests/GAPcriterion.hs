
module Main where

import ADP.Fusion.GAPlike2.Criterion



main = criterionMain

